/* Plain-browser build (used by the automated tests only). Nothing platform-specific. */
