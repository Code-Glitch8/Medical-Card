/* Android shell shim (loaded as platform.js). Runs inside the app's WebView on the app's private origin only.
 *
 * The page talks to the RFID reader with the browser Web Serial API (navigator.serial: requestPort / open /
 * readable.getReader / writable.getWriter / close). Android WebView has no Web Serial, so this file provides a minimal,
 * API-compatible navigator.serial on top of the native Bluetooth Classic (SPP/RFCOMM) bridge. The bytes are passed through
 * untouched, so the Arduino protocol (ARM:/WRITE:/CARD:/CODE:/INFO:/ERR: lines) is exactly what the website uses.
 * It also provides window.EMR_STORAGE: an async key/value store backed by Android Keystore encryption, used by supabase-js
 * for the login session (the website uses sessionStorage instead).
 *
 * `EMRNative` is injected by the native side (WebViewCompat.addWebMessageListener) only for the app's own origin. */
(function () {
  'use strict';
  window.EMR_REDIRECT_TO = 'medicalcard://auth-callback';
  var N = window.EMRNative;
  if (!N || typeof N.postMessage !== 'function') return; // not inside the Android app: leave the page unchanged

  var seq = 0, pending = {}, onData = null, onClosed = null;

  function b64ToBytes(s) { var bin = atob(s), a = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return a; }
  function bytesToB64(u8) { var s = ''; for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]); return btoa(s); }
  function domErr(name, message) { try { return new DOMException(message, name); } catch (e) { var er = new Error(message); er.name = name; return er; } }

  N.onmessage = function (ev) {
    var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
    if (m.id !== undefined && pending[m.id]) {
      var p = pending[m.id]; delete pending[m.id]; clearTimeout(p.t);
      if (m.ok) p.res(m); else p.rej(domErr(m.name || 'NetworkError', m.message || 'Request failed.'));
    } else if (m.event === 'serial.data' && onData) { onData(b64ToBytes(m.b64)); }
    else if (m.event === 'serial.closed' && onClosed) { onClosed(m.reason || 'closed'); }
  };

  function rpc(cmd, args, timeoutMs) {
    return new Promise(function (res, rej) {
      var id = ++seq, o = { res: res, rej: rej, t: null };
      if (timeoutMs) o.t = setTimeout(function () { delete pending[id]; rej(domErr('TimeoutError', 'The device did not respond in time.')); }, timeoutMs);
      pending[id] = o;
      var msg = { id: id, cmd: cmd }; for (var k in args) if (Object.prototype.hasOwnProperty.call(args, k)) msg[k] = args[k];
      N.postMessage(JSON.stringify(msg));
    });
  }

  // ---- secure session store (async; supabase-js supports promise-returning storage) ----------------------------------
  window.EMR_STORAGE = {
    getItem: function (k) { return rpc('store.get', { key: k }, 8000).then(function (r) { return r.value === undefined ? null : r.value; }); },
    setItem: function (k, v) { return rpc('store.set', { key: k, value: String(v) }, 8000).then(function () {}); },
    removeItem: function (k) { return rpc('store.remove', { key: k }, 8000).then(function () {}); },
  };

  // ---- Web Serial subset over Bluetooth Classic SPP --------------------------------------------------------------------
  function SerialPortShim(info) { this._info = info; this._open = false; this.readable = null; this.writable = null; this._ctrl = null; }
  SerialPortShim.prototype.getInfo = function () { return {}; };
  SerialPortShim.prototype.open = function (opts) {
    var self = this;
    if (self._open) return Promise.reject(domErr('InvalidStateError', 'The port is already open.'));
    // The baud rate belongs to the HC-05/Arduino UART; an SPP link has no baud rate of its own, so it is accepted and ignored.
    return rpc('serial.open', { address: self._info.address }, 25000).then(function () {
      self._open = true;
      self.readable = new ReadableStream({
        start: function (c) { self._ctrl = c; },
        cancel: function () { return Promise.resolve(); },
      });
      self.writable = new WritableStream({
        write: function (chunk) { return rpc('serial.write', { b64: bytesToB64(chunk) }, 8000).then(function () {}); },
      });
      onData = function (u8) { try { self._ctrl.enqueue(u8); } catch (e) { /* stream already cancelled */ } };
      onClosed = function () { self._finish(); };
    });
  };
  SerialPortShim.prototype._finish = function () {
    if (!this._open) return;
    this._open = false;
    onData = null; onClosed = null;
    try { this._ctrl.close(); } catch (e) { /* already closed */ }
    this.readable = null; this.writable = null;
  };
  SerialPortShim.prototype.close = function () {
    var self = this;
    if (!self._open) return Promise.resolve();
    return rpc('serial.close', {}, 8000).catch(function () {}).then(function () { self._finish(); });
  };

  var serial = {
    requestPort: function () {
      return rpc('serial.pick', {}, 0).then(function (r) { return new SerialPortShim({ address: r.address, name: r.name }); });
    },
    getPorts: function () { return Promise.resolve([]); },
    addEventListener: function () {}, removeEventListener: function () {},
  };
  try { Object.defineProperty(navigator, 'serial', { value: serial, configurable: true }); } catch (e) { /* leave manual entry */ }
})();
