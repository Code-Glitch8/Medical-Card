/* Windows (Electron) shell: Chromium already provides navigator.serial, and the preload script provides
 * window.EMR_STORAGE (DPAPI-encrypted via Electron safeStorage). Only the reset-link redirect is set here. */
window.EMR_REDIRECT_TO = 'medicalcard://auth-callback';
