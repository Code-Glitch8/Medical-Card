/* Shared by the Android and Windows apps. Loaded before the page's own script.
 * 1. Unsaved-edit guard: asks before leaving a half-filled data-entry form (navigation, Back, sign-out).
 * 2. window.__emrBack(): lets a native shell ask the page to "go back one step". Returns 'handled' or 'exit'.
 * Contains no secrets and makes no network calls. */
(function () {
  'use strict';
  var dirty = false;
  var FORMS = ['personForm', 'eventForm', 'allergyForm', 'conditionForm', 'medForm', 'vaxForm', 'hospitalForm', 'pwForm'];
  var GUARDED = '#mainNav [data-nav], #backHomeBtn, #backFromRecordsBtn, #cancelPerson, #cancelEvent, #cancelAssign, #lockBtn';

  document.addEventListener('input', function (e) {
    var f = e.target && e.target.closest ? e.target.closest('form') : null;
    if (f && FORMS.indexOf(f.getAttribute('id')) >= 0) dirty = true;
  }, true);

  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest(GUARDED) : null;
    if (!b || !dirty) return;
    if (window.confirm('You have unsaved changes. Leave without saving?')) { dirty = false; return; }
    e.stopImmediatePropagation();
    e.preventDefault();
  }, true);

  // The page replaces #main's content after a save or navigation, which also discards any pending edits.
  function watchMain() {
    var m = document.getElementById('main');
    if (!m || typeof MutationObserver === 'undefined') return;
    new MutationObserver(function () { dirty = false; }).observe(m, { childList: true });
  }
  if (document.getElementById('main')) watchMain(); else document.addEventListener('DOMContentLoaded', watchMain);

  window.__emrIsDirty = function () { return dirty; };

  function visible(el) { return !!el && !el.hidden && el.offsetParent !== null; }
  var BACK_ORDER = ['#pubBackCode', '#pubBackLogin', '#regBack', '#recoveryCancel', '#cancelPerson', '#cancelEvent', '#cancelAssign', '#backFromRecordsBtn', '#backHomeBtn'];
  window.__emrBack = function () {
    for (var i = 0; i < BACK_ORDER.length; i++) {
      var el = document.querySelector(BACK_ORDER[i]);
      if (visible(el)) { el.click(); return 'handled'; }
    }
    return 'exit';
  };
})();
