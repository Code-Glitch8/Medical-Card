#!/usr/bin/env python3
"""Automated (simulated) tests of the built web bundle in headless Chromium.
  * serves dist/<target>/www with the real CSP meta tag active
  * replaces supabase-js with test/fake-supabase.mjs (no network here)
  * for the Android bundle, emulates the native Bluetooth/storage bridge (an HC-05 stand-in)
Usage: python3 test/bundle_test.py <dist-dir>"""
import sys, pathlib, mimetypes, json
from playwright.sync_api import sync_playwright
dist = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else 'dist')
res = []
def check(n, c, info=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n + ('' if c else '  -> ' + str(info)))

NATIVE = r"""
window.__native = {sent: [], store: {}, open: false, opens: 0};
(function () {
  const send = (o) => window.EMRNative.onmessage({ data: JSON.stringify(o) });
  window.EMRNative = { onmessage: null, postMessage(s) {
    const m = JSON.parse(s);
    setTimeout(() => {
      switch (m.cmd) {
        case 'serial.pick': send({ id: m.id, ok: true, address: '00:11:22:33:44:55', name: 'HC-05' }); break;
        case 'serial.open': if (window.__native.failOpen) send({ id: m.id, ok: false, name: 'NetworkError', message: 'Could not connect to the reader.' }); else { window.__native.open = true; window.__native.opens++; send({ id: m.id, ok: true }); } break;
        case 'serial.write': window.__native.sent.push(atob(m.b64)); send({ id: m.id, ok: true }); break;
        case 'serial.close': window.__native.open = false; send({ id: m.id, ok: true }); break;
        case 'store.get': send({ id: m.id, ok: true, value: m.key in window.__native.store ? window.__native.store[m.key] : undefined }); break;
        case 'store.set': window.__native.store[m.key] = m.value; send({ id: m.id, ok: true }); break;
        case 'store.remove': delete window.__native.store[m.key]; send({ id: m.id, ok: true }); break;
      }
    }, 0);
  } };
  window.__emit = (s) => send({ event: 'serial.data', b64: btoa(s) });
  window.__emitClosed = () => send({ event: 'serial.closed', reason: 'link lost' });
})();
"""
def wait_js(p, expr, timeout=5000):
    import time
    end = time.time() + timeout / 1000
    while time.time() < end:
        if p.evaluate(expr): return True
        p.wait_for_timeout(50)
    raise TimeoutError(expr)
with sync_playwright() as pw:
    b = pw.chromium.launch()
    ctx = b.new_context(viewport={'width': 390, 'height': 800}); p = ctx.new_page()
    errs = []
    p.on('pageerror', lambda e: errs.append(str(e)))
    p.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    android = dist.name == 'android'
    if android: p.add_init_script(NATIVE)
    p.add_init_script("window.__csp=[];document.addEventListener('securitypolicyviolation',e=>window.__csp.push(e.violatedDirective+' '+e.blockedURI));")
    def serve(route):
        u = route.request.url.split('://app.test', 1)[1].split('?')[0].split('#')[0] or '/'
        f = dist / 'www' / (u.lstrip('/') or 'index.html')
        if not f.is_file(): route.fulfill(status=404, body='nf'); return
        route.fulfill(body=f.read_bytes(), content_type=mimetypes.guess_type(str(f))[0] or 'text/plain')
    p.route('http://app.test/**', serve)
    p.on('dialog', lambda d: (setattr(p, '_dlg', d.message), d.dismiss() if getattr(p, '_dismiss', False) else d.accept('x')))
    p.goto('http://app.test/index.html'); p.wait_for_selector('#loginForm')
    p.wait_for_timeout(300)
    check('bundle loads; CSP active; zero CSP violations', p.evaluate('window.__csp.length') == 0, p.evaluate('window.__csp'))
    check('CSP meta present with script hash', 'sha256-' in p.evaluate("document.querySelector('meta[http-equiv=Content-Security-Policy]').content"))
    check('no JS errors on load', not errs, errs)
    check('login page uses configured project (not "not configured")', 'not configured' not in p.inner_text('body'))
    # inline eval blocked by CSP (defence in depth)
    p.evaluate("window.__x=0;const s=document.createElement('script');s.textContent='window.__x=1';document.body.appendChild(s)"); p.wait_for_timeout(100)
    check('injected inline <script> blocked by CSP (and reported)', p.evaluate('window.__x') == 0 and any('script-src' in v for v in p.evaluate('window.__csp')))
    p.evaluate("window.__csp.length=0"); errs.clear()
    # public lookup viewer
    p.click('#pubToLogin') if p.query_selector('#pubToLogin') and p.is_visible('#pubToLogin') else None
    if p.query_selector('#publicLookupCard') and p.is_visible('#publicLookupCard'): pass
    # demo mode
    p.fill('#loginId', 'h1@x.org'); p.fill('#loginPass', 'correct-horse-1'); p.click('#loginSubmit'); p.wait_for_selector('#appView:not(.hidden)')
    check('hospital sign-in works in the bundle', 'City General' in p.inner_text('#hospitalName'))
    if android:
        check('navigator.serial provided by shim', p.evaluate("'serial' in navigator"))
        check('EMR_STORAGE provided', p.evaluate("typeof window.EMR_STORAGE.getItem") == 'function')
        p.evaluate("window.EMR_STORAGE.setItem('sb-test-auth-token','tok')"); p.wait_for_timeout(50)
        check('EMR_STORAGE round-trip via native', p.evaluate("window.EMR_STORAGE.getItem('sb-test-auth-token')") == 'tok' and p.evaluate("window.EMR_STORAGE.getItem('nope')") is None)
        # connect reader
        p.click('#headerConnectBtn'); wait_js(p, "document.getElementById('readerStatus').textContent==='Reader connected'", 5000)
        check('reader shows connected only after native open succeeded', p.evaluate('window.__native.open') is True)
        # split chunks, CRLF, as a real SPP stream would deliver
        p.evaluate("window.__emit('CODE:12345')"); p.wait_for_timeout(50); p.evaluate("window.__emit('67890\\r\\n')"); p.wait_for_timeout(400)
        check('serial line CODE:<10 digits> reassembled and handled (profile opened)', p.evaluate('activePerson')=='P1' and 'open_patient_by_card' in p.evaluate('window.__calls'), p.evaluate('window.__calls'))
        p.evaluate("sendSerialLine('ARM:1234567890')"); p.wait_for_timeout(100)
        check('page -> Arduino bytes pass through unchanged ("ARM:1234567890\\n")', p.evaluate('window.__native.sent') == ['ARM:1234567890\n'], p.evaluate('window.__native.sent'))
        p.evaluate("window.__emitClosed()"); wait_js(p, "document.getElementById('readerStatus').textContent==='Reader disconnected'", 3000)
        check('link loss -> "Reader disconnected" (never stays "connected")', 'Connect reader' in p.inner_text('#headerConnectBtn'))
        p.evaluate("window.__native.failOpen=true"); p.click('#headerConnectBtn'); p.wait_for_timeout(500)
        check('failed connect shows error state, not connected', p.inner_text('#readerStatus') != 'Reader connected' and 'Could not connect' in p.inner_text('#toast'), p.inner_text('#toast'))
        p.evaluate("window.__native.failOpen=false"); p.click('#headerConnectBtn'); p.wait_for_timeout(200)  # existing website quirk: first click after a failed connect only resets the port
        p.click('#headerConnectBtn'); wait_js(p, "document.getElementById('readerStatus').textContent==='Reader connected'", 5000)
        check('reconnect after failure works', p.evaluate('window.__native.opens') == 2)
        p.click('#headerConnectBtn'); wait_js(p, "document.getElementById('readerStatus').textContent==='Reader disconnected'", 3000)
        check('manual disconnect closes native link', p.evaluate('window.__native.open') is False)
    # unsaved-edit guard + back
    p.evaluate("renderPage('addPerson')"); p.wait_for_selector('#personForm')
    p.fill('#personForm [name=name]', 'Typed Name')
    p._dismiss = True; p.click('#mainNav [data-nav=lookup]'); p.wait_for_timeout(150)
    check('unsaved edits: confirm shown and navigation cancelled on "Cancel"', 'unsaved' in getattr(p, '_dlg', '') and p.query_selector('#personForm') is not None)
    p._dismiss = False; p.click('#mainNav [data-nav=lookup]'); p.wait_for_timeout(150)
    check('unsaved edits: navigation proceeds after "OK"', p.query_selector('#personForm') is None)
    p.evaluate("renderPage('addPerson')"); p.wait_for_selector('#personForm')
    check('__emrBack() steps back from a form', p.evaluate('window.__emrBack()') == 'handled' and p.query_selector('#personForm') is None)
    check('__emrBack() reports exit at top level', p.evaluate('window.__emrBack()') == 'exit')
    check('no JS errors during run', not errs, errs)
    b.close()
print(f'\n{sum(res)}/{len(res)} passed'); sys.exit(0 if all(res) else 1)
