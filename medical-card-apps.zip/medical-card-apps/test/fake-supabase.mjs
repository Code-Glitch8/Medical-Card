// Tiny in-memory stand-in for supabase-js, enough to drive the real page in a headless browser.
const now = () => new Date().toISOString();
const db = {
  app_users: [{ user_id: 'U1', role: 'hospital', hospital_id: 'H1' }, { user_id: 'UA', role: 'admin', hospital_id: null }],
  hospitals: [{ id: 'H1', name: 'City General', address: '1 Rd', city: 'Pune', state: 'MH', pin: '411001', country: 'IN', phone: '+91 20 1234 5678', admin_contact: 'Dr A', email: 'h1@x.org', login_id: 'city.general', status: 'active', status_reason: null, created_at: now(), updated_at: now() },
                { id: 'H2', name: 'New Clinic', address: '2 Rd', city: 'Pune', state: 'MH', pin: '411002', country: 'IN', phone: '+91 20 1234 5679', admin_contact: 'Dr B', email: 'h2@x.org', login_id: 'new.clinic', status: 'pending', created_at: now(), updated_at: now() }],
  patients: [{ id: 'P1', code16: '1234567890', name: 'Asha Rao', preferred: '', dob: '1990-01-01', sex: '', blood_group: 'O+', blood_status: 'verified', blood_date: '2025-01-01', blood_source: 'Lab', emergency_name: 'Ravi', emergency_phone: '+91 99999 11111', important_notes: '', allergy_status: 'unknown', allergies: [], conditions: [], medications: [], records: [], vaccinations: [], contacts: [], timeline: [], version: 1, created_by_hospital_id: 'H1', created_by_hospital_name: 'City General', created_at: now(), updated_at: now() }],
  patient_history: [], audit_logs: [],
};
window.__calls = window.__calls || [];
const users = { 'h1@x.org': { id: 'U1', email: 'h1@x.org', pw: 'correct-horse-1' }, 'admin@x.org': { id: 'UA', email: 'admin@x.org', pw: 'admin-password-1' } };
let listeners = [], session = null;
const emit = (ev) => listeners.forEach((l) => l(ev, session));
class Q {
  constructor(t) { this.t = t; this.rows = db[t].slice(); this.f = []; this.cnt = false; }
  select(_c, o) { this.cnt = !!(o && o.count); this.head = !!(o && o.head); return this; }
  eq(k, v) { this.rows = this.rows.filter((r) => r[k] === v); return this; }
  order(k, o) { const d = o && o.ascending === false ? -1 : 1; this.rows.sort((a, b) => (a[k] > b[k] ? d : -d)); return this; }
  limit(n) { this.rows = this.rows.slice(0, n); return this; }
  maybeSingle() { return Promise.resolve({ data: this.rows[0] || null, error: null }); }
  single() { return Promise.resolve(this.rows[0] ? { data: this.rows[0], error: null } : { data: null, error: { code: 'PGRST116', message: 'no rows' } }); }
  then(res, rej) { return Promise.resolve(this.cnt ? { data: null, count: this.rows.length, error: null } : { data: this.rows, error: null }).then(res, rej); }
}
const E = (code, message) => ({ data: null, error: { code, message } });
const rpcs = {
  global_profile_count: () => ({ data: 1, error: null }),
  public_lookup_patient_by_code: (a) => /^[0-9]{10}$/.test(String(a.p_code).trim()) ? (a.p_code === '1234567890' ? { data: { status: 'ok', patient: { name: 'Asha Rao', blood_group: 'O+', blood_status: 'verified', emergency_name: 'Ravi', emergency_phone: '+91 99999 11111', allergies: [], conditions: [], medications: [], records: [], vaccinations: [], contacts: [], updated_at: now() } }, error: null } : { data: { status: 'not_found' }, error: null }) : { data: { status: 'invalid' }, error: null },
  create_patient: (a) => { const id = 'P' + (db.patients.length + 1); db.patients.push({ ...db.patients[0], id, code16: '5555555555', name: a.p_patient.name, version: 1, updated_at: now() }); return { data: { patientId: id, code16: '5555555555' }, error: null }; },
  open_patient_by_card: (a) => { const p = db.patients.find((x) => x.code16 === a.p_code); return { data: p || null, error: null }; },
  log_patient_access: () => ({ data: { ok: true }, error: null }),
  save_patient: (a) => { if (a.p_expected_version !== db.patients.find((x) => x.id === a.p_id).version) return E('EM004', 'Another hospital updated this profile first.'); const p = db.patients.find((x) => x.id === a.p_id); p.name = a.p_patient.name; p.version++; return { data: { version: p.version }, error: null }; },
  set_hospital_status: (a) => { db.hospitals.find((h) => h.id === a.p_hospital_id).status = a.p_status; return { data: {}, error: null }; },
  update_hospital_profile: () => ({ data: { ok: true }, error: null }),
  record_card_programmed: () => ({ data: { replaced: false }, error: null }),
};
export function createClient() {
  return {
    auth: {
      onAuthStateChange(cb) { listeners.push(cb); setTimeout(() => cb('INITIAL_SESSION', session), 0); return { data: { subscription: {} } }; },
      async signInWithPassword({ email, password }) { const u = users[email]; if (!u || u.pw !== password) return { data: {}, error: { code: 'invalid_credentials', message: 'Invalid login credentials', status: 400 } }; const first = !session; session = { user: { id: u.id, email } }; if (first) emit('SIGNED_IN'); else emit('SIGNED_IN'); return { data: { session }, error: null }; },
      async setSession(t) { session = { user: { id: 'U1', email: 'h1@x.org' } }; emit('SIGNED_IN'); return { data: { session }, error: null }; },
      async signOut() { session = null; emit('SIGNED_OUT'); return { error: null }; },
      async updateUser() { return { data: {}, error: null }; },
    },
    from: (t) => new Q(t),
    rpc: async (fn, a) => { window.__calls.push(fn); return rpcs[fn] ? rpcs[fn](a) : { data: null, error: { code: 'PGRST202', message: 'unknown function ' + fn } }; },
    channel() { const c = { on() { return c; }, subscribe() { return c; } }; return c; },
    removeChannel() {},
    functions: { async invoke(name, { body }) {
      window.__calls.push(name);
      if (name === 'login-with-id') return body.password === 'correct-horse-1' && String(body.loginId).toLowerCase() === 'city.general' ? { data: { access_token: 'a', refresh_token: 'r' }, error: null } : { data: null, error: { message: 'x', context: new Response(JSON.stringify({ error: { code: 'unauthenticated', message: 'Incorrect login ID/email or password.' } })) } };
      if (name === 'register-hospital') return { data: { hospitalId: 'H9', status: 'pending' }, error: null };
      return { data: { ok: true }, error: null };
    } },
  };
}
