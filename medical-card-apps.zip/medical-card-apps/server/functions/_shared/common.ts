// Shared helpers for the Edge Functions. SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY are injected
// by Supabase into every hosted Edge Function; the service-role key never leaves the server.
import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

// Comma-separated list of origins allowed to call the functions from a browser/app WebView. Default (unset) = '*', as before.
// If you restrict it for the website, ADD the two app origins or the apps' sign-in will be blocked by CORS:
//   ALLOWED_ORIGIN=https://code-glitch8.github.io,https://appassets.androidplatform.net,app://medicalcard
const ALLOWED_ORIGINS = (Deno.env.get('ALLOWED_ORIGIN') || '*').split(',').map((s) => s.trim()).filter(Boolean);
const ALLOWED_ORIGIN = ALLOWED_ORIGINS.includes('*') ? '*' : ALLOWED_ORIGINS[0];
const withOrigin = (req: Request, res: Response): Response => {
  if (ALLOWED_ORIGIN === '*') return res;
  const o = req.headers.get('origin') ?? '';
  const h = new Headers(res.headers);
  h.set('Access-Control-Allow-Origin', ALLOWED_ORIGINS.includes(o) ? o : ALLOWED_ORIGINS[0]);
  h.set('Vary', 'Origin');
  return new Response(res.body, { status: res.status, headers: h });
};

export const cors = {
  'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Vary': 'Origin',
};

export const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
export const fail = (status: number, code: string, message: string) => json(status, { error: { code, message } });

export const admin = (): SupabaseClient =>
  createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false, autoRefreshToken: false } });
export const anon = (): SupabaseClient =>
  createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { auth: { persistSession: false, autoRefreshToken: false } });

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
export const LOGIN_RE = /^[A-Za-z0-9._-]{3,40}$/;
export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const GENERIC_LOGIN = 'Incorrect login ID/email or password.';

/** Wraps a handler with CORS, method checks and JSON body parsing. */
export function serve(handler: (body: Record<string, unknown>) => Promise<Response>) {
  Deno.serve(async (req) => {
    if (req.method === 'OPTIONS') return withOrigin(req, new Response('ok', { headers: cors }));
    if (req.method !== 'POST') return withOrigin(req, fail(405, 'invalid-argument', 'Method not allowed.'));
    let body: Record<string, unknown> = {};
    try { body = await req.json(); } catch { return withOrigin(req, fail(400, 'invalid-argument', 'Invalid request.')); }
    try { return withOrigin(req, await handler(body ?? {})); }
    catch (e) { console.error(e); return withOrigin(req, fail(500, 'internal', 'The service is temporarily unavailable. Please try again.')); }
  });
}
