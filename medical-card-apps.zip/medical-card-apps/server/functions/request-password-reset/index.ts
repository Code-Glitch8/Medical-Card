// Password reset by login ID or e-mail. ALWAYS answers {ok:true}, whether or not an account exists, and sends at most
// one e-mail per address per minute. The link in the e-mail returns to SITE_URL, where the app shows a "set new
// password" form (Supabase "recovery" session).
import { admin, anon, json, serve, EMAIL_RE, LOGIN_RE } from '../_shared/common.ts';

serve(async (b) => {
  const ok = () => json(200, { ok: true });
  const ident = String(b.identifier ?? '').trim().toLowerCase();
  if (!ident || ident.length > 150) return ok();
  const sb = admin();
  let email: string | null = null, uid: string | null = null;
  if (ident.includes('@')) {
    if (!EMAIL_RE.test(ident)) return ok();
    email = ident;
  } else {
    if (!LOGIN_RE.test(ident)) return ok();
    const { data } = await sb.rpc('auth_lookup_login', { p_login_id: ident });
    const row = Array.isArray(data) ? data[0] : null;
    if (!row) return ok();
    email = row.email; uid = row.user_id;
  }
  const { data: allowed } = await sb.rpc('auth_reset_cooldown', { p_ident: email });
  if (!allowed) return ok();
  try {
    // The website sends nothing (SITE_URL is used, as before). The Android/Windows apps send 'medicalcard://auth-callback'.
    // Only an allow-listed value is ever used; anything else falls back to SITE_URL. Every value must ALSO be listed in
    // Supabase Dashboard → Authentication → URL Configuration → Redirect URLs.
    const site = Deno.env.get('SITE_URL') || undefined;
    const allowed = new Set([site, 'medicalcard://auth-callback'].filter(Boolean) as string[]);
    const asked = typeof b.redirectTo === 'string' ? b.redirectTo : '';
    const redirectTo = allowed.has(asked) ? asked : site;
    await anon().auth.resetPasswordForEmail(email!, { redirectTo });
    if (uid) await sb.rpc('log_auth_event', { p_user: uid, p_action: 'auth.password_reset_requested', p_summary: 'Password reset email requested' });
  } catch { /* never reveal whether the account exists */ }
  return ok();
});
