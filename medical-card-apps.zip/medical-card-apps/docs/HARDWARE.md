# Card reader (HC-05 + Arduino) — setup and limits

The Arduino sketch and its text protocol are **unchanged**. This is untested with real hardware.

## Android
1. Power the reader. In **Android Settings ▸ Bluetooth** pair the HC-05 (default PIN `1234`, sometimes `0000`). The app never scans; it lists **already-paired** devices only.
2. In the app open the page's reader connection → "Choose the card reader" lists paired devices → pick yours. On Android 12+ allow the "Nearby devices" (Bluetooth) permission when asked.
3. Choose the same baud rate as before in the page's selector (the HC-05↔Arduino UART speed is set on the module, not by Android).
4. If anything fails the page shows its normal "not connected" state with the reason (Bluetooth off, not paired, out of range, permission denied). You can always type the 10-digit code manually.

## Windows
1. Pair the HC-05 in **Windows Settings ▸ Bluetooth** — Windows creates an *outgoing* COM port (Device Manager ▸ Ports). Or plug in a USB-serial reader.
2. In the app click connect → the chooser lists COM ports → pick the right one → baud rate from the page's selector.

## Known limits
* Android supports Bluetooth **Classic SPP** only (HC-05/HC-06). BLE modules (HM-10) and USB-OTG serial are **not** supported.
* One reader connection at a time; leaving the page or locking the app closes it.
* Android: if the reader drops, the page sees the stream end and shows disconnected; reconnect by choosing the reader again.
* Never shown as connected until the link really opened; never shown as "card scanned" without a `CARD:`/`CODE:` line from the Arduino.
* Not tested with hardware: timing, buffering of partial lines at the byte level (bytes are forwarded as received in ≤512-byte chunks; the page's own line parser handles reassembly exactly as on the website).
