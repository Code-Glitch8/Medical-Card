# Architecture

## Why "the website inside a shell"
The website is a single HTML file containing all features (sign-in, registration, recovery, patient CRUD, history/audit,
admin, public lookup, themes, hardware). Rewriting it natively would duplicate every rule and drift from the site. Instead each app
ships **the same `index.html`** inside the package and adds only what a browser tab cannot do.

```
web/index.html (unmodified)
      │  scripts/build-www.mjs  (3 exact-once patches, CSP hash, vendored supabase-js, secret scan)
      ▼
dist/<target>/www/{index.html, app-common.js, platform.js, vendor/supabase.js}
      │                                   │
      ▼ Android                           ▼ Windows
 WebView @ https://appassets.androidplatform.net     Electron window @ app://medicalcard
 + EMRNative web-message bridge (Kotlin)             + preload EMR_STORAGE (safeStorage/DPAPI)
   · Keystore-encrypted session store                + Chromium's native Web Serial → COM-port picker
   · Bluetooth Classic SPP ⇒ navigator.serial shim
      │                                   │
      └──────────── HTTPS / WSS only ─────┴──► https://pkzzktnxiboottirasvc.supabase.co  (same project as the website)
```

## The three patches to the page (see CHANGES.md)
1. supabase-js is loaded from the bundle (`./vendor/supabase.js`) instead of a CDN → works under a strict CSP, pinned version, no third-party host at run time.
2. `storage: window.EMR_STORAGE || window.sessionStorage` → the website is unchanged (sessionStorage); the apps keep the login session in encrypted native storage so it survives app restarts, while patient data is never stored.
3. The password-reset request also sends `redirectTo: window.EMR_REDIRECT_TO || undefined` → apps can receive the reset link via `medicalcard://auth-callback`. A server that ignores the extra field behaves exactly as before.

## Hardware path (unchanged protocol)
The page calls `navigator.serial.requestPort()`, `port.open({baudRate})`, `readable.getReader()`, `writable.getWriter()` and exchanges the
Arduino's text lines (`ARM:`, `WRITE:`, `CARD:`, `CODE:`, `INFO:`, `ERR:`). Not one byte of that is changed.
* **Windows:** Chromium (Electron) implements Web Serial itself. Main process only supplies the picker window and permits `serial` for the app origin. The baud rate comes from the page's existing selector.
* **Android:** WebView has no Web Serial. `platform-android.js` installs a minimal, API-compatible `navigator.serial` whose port talks to Kotlin (`BluetoothSerial`) over RFCOMM/SPP (UUID `00001101-…`) to a **paired** HC-05. Bytes pass through unchanged (verified with a simulated HC-05 bridge). The baud rate is a property of the HC-05↔Arduino UART, so the SPP link ignores it.
* Connection state is only shown after a real connect succeeded; connect failures, link loss and denied permissions reject/close the port, so the UI never claims "connected" or "card scanned" falsely. Manual 10-digit entry never needs hardware.

## Security model (details in SECURITY.md)
* Android: `WebViewAssetLoader` virtual HTTPS origin; no `file://`; no `addJavascriptInterface` (a `WebMessageListener` restricted to the app origin and main frame instead); all navigation/sub-resources classified (app / Supabase / external-in-browser / blocked); `FLAG_SECURE`; no backup; no cleartext; `LOAD_NO_CACHE`.
* Windows: `contextIsolation`, `sandbox`, no Node in the renderer, custom `app://` scheme with path-traversal-safe handler, session-level network allow-list, permissions denied except `serial` for the app origin, navigation + `window.open` locked, content protection.
* Both: hash-based CSP (`script-src 'self' 'sha256-…'`, `connect-src` Supabase https/wss only), session tokens encrypted by the OS keystore, patient data held only in page memory, public-lookup data cleared when the app is left.

## Trade-offs
| Choice | Why | Cost |
|---|---|---|
| WebView/Electron shell, not native screens | One source of truth, all features preserved | Larger package (Electron ≈ 80–100 MB installer); depends on system WebView on Android |
| Electron, not WebView2/Tauri, on Windows | WebView2 has no Web Serial; Electron's Chromium does, so the existing serial code needs **zero** changes | Must be kept updated (see SECURITY.md) |
| Bundled supabase-js instead of CDN | Strict CSP, offline-capable start, no third-party script host | Updating supabase-js means rebuilding the app |
| Session stored natively | Users stay signed in across restarts | Token on disk (encrypted by OS keystore/DPAPI); auto-lock still signs out after inactivity |
| No offline mode | Medical data must not be cached on devices | App needs a connection to be useful |
