# What changed, added, removed

## Changes to the website file
**`web/index.html` is byte-identical to the file you supplied; the website needs no change and keeps working.** The apps use a *copy*
patched at build time in exactly three places (each asserted to match once):

| # | Original text | Replaced by | Why |
|---|---|---|---|
| 1 | `const m=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@'+SUPABASE_JS+'/+esm');` | `const m=await import('./vendor/supabase.js');` | CSP-safe, bundled supabase-js |
| 2 | `storage:window.sessionStorage,` | `storage:(window.EMR_STORAGE||window.sessionStorage),` | encrypted native session store in the apps |
| 3 | `await call('requestPasswordReset',{identifier:$('forgotId').value.trim()})` | same call plus `,redirectTo:window.EMR_REDIRECT_TO||undefined` | reset link can return to the app |

Also injected into the copy: a CSP `<meta>` (hash of the single inline script), and `<script src="app-common.js">` + `<script src="platform.js">`.
Neither of those exists in the website file.

## Added (everything under the project except the two items below)
`scripts/`, `shared/`, `android/`, `windows/`, `server/`, `test/`, `docs/`, `.github/workflows/build.yml`, `package.json`, `.gitignore`, `README.md`.
Your `public_lookup_migration.sql`, `verify_anon_privileges.sql` and `PUBLIC_LOOKUP_INSTALL_AND_TEST.md` are copied **unchanged** (file names carry an upload-id prefix).

## Removed
Nothing. The earlier Phase-1 deliverables (`supabase-emr.zip`, `RF.HTML`) are separate and untouched.

## Unsupported / limitations
* No offline mode (by design: no medical data cached on devices).
* Android: Bluetooth Classic SPP only; no BLE, no USB-OTG; Bluetooth never exercised on hardware.
* Public lookup accepts only 10-digit codes (as your migration defines); legacy 16-digit codes cannot use it.
* Reset links return to the app only after the optional server patch + Auth redirect URL; otherwise they open the website.
* Windows installer is x64 only and unsigned by default; Windows 10+ only (Electron's requirement).
* iOS/macOS/Linux builds are not provided.
* Same limits as the website: needs a network connection and a working Supabase project.
