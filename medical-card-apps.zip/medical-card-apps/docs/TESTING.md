# Testing — what was run, what was only simulated, what you must do

Legend: **A** = automated and actually executed here · **S** = simulated (stand-in for the real thing) · **M** = manual, not done · **H** = needs hardware, not done.

## Executed in my environment
| # | What | Kind | Result |
|---|---|---|---|
| 1 | `build-www.mjs` on unmodified `web/index.html`: all patches match exactly once; CSP hash; secret scan | A | pass |
| 2 | Android bundle in headless Chromium, real CSP, **fake supabase-js**: page loads with zero CSP violations, an injected inline script is blocked, hospital sign-in works, `navigator.serial` + `EMR_STORAGE` shims present, storage round-trip, reader shows connected only after native open succeeded, `CODE:` line reassembled and handled, `ARM:` bytes unchanged, link loss → disconnected, failed connect → error state, reconnect, manual disconnect, unsaved-edit guard (cancel / OK), `__emrBack()` behaviour, no JS errors | A+S | **21/21** |
| 3 | Same checks for the Windows bundle minus the Android-only serial/storage shim checks (the page, CSP, sign-in, edit guard and Back checks) | A+S | **11/11** |
| 4 | Simulated HC-05 bridge: bytes forwarded unchanged (`ARM:1234567890` checked byte-for-byte; `WRITE:` not separately tested); link loss → disconnected; failed connect never shows connected; no "scanned" without data | S | pass (inside #2) |
| 5 | `windows/src/lib.js` + `secure-store.js` unit tests (`node --test`): traversal, URL classification, request allow-list, deep links, store whitelist, no plaintext persistence | A | **8/8** |
| 5b | **Not covered by any automated test:** registration, password reset, patient create/edit, history/audit, admin, public lookup, themes — these pages are the website's own unmodified code, but they were not exercised against the bundle by me. Covered only by the manual list below. | — | not run |
| 6 | `node --check` on all JS; XML well-formedness of all Android resources; brace/paren balance of Kotlin; workflow YAML parses | A (static only) | pass |

## Written but NOT run
| What | Why |
|---|---|
| `PolicyTest.kt` (URL/key/MAC/deep-link rules for Android) | no Kotlin/JVM toolchain; runs with `gradle :app:testDebugUnitTest` (also in CI) |
| All Kotlin (`MainActivity`, `NativeBridge`, `BluetoothSerial`, `SecureStore`) | **never compiled** |
| Electron `main.js` / preloads / picker | **never launched** |
| electron-builder / Gradle packaging | not run |

## Manual checklist (M) — run on a real device / PC against your real Supabase
Both apps: sign in (login ID and email) · wrong password message · hospital registration → pending-approval restrictions · password reset (see BUILD §5–6) · dashboard loads · create / view / edit patient · history & audit · admin functions as admin user · public lookup valid / invalid / rate-limited · bearer-code warning visible, no expanded data · light/dark theme persists · field validation · logout · kill app and reopen (session restored; still locked after the auto-lock time) · airplane mode (clear error, no crash) · website still works unchanged in a browser · confirm in Supabase logs that the apps hit the same project.
Android: rotate · back button steps back then asks to exit · screenshot is blocked (release build) · recents thumbnail blank · switch away > auto-lock minutes → signed out on return · open reset link `medicalcard://auth-callback#…` · external link opens in browser · Bluetooth permission denied path · Bluetooth off path · Android 8, 12, 14/15.
Windows: install (no admin) · shortcuts · uninstall removes data · second launch focuses the first window · reset link opens the running app · lock/unlock Windows → signed out after idle time · SmartScreen text.
**H — hardware:** pair HC-05 · connect · ARM/write a card · scan a card (`CARD:`/`CODE:`) · power-off reader mid-session (UI shows disconnected) · wrong COM port · wrong baud rate · reconnect.
