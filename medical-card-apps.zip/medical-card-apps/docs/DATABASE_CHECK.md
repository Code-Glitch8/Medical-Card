# Database: what the apps need, and how to check/deploy the public-lookup migration

**I did not change the database and did not verify your deployed one.** The apps use exactly what the website uses. The only
database object that is new relative to the older website is the public lookup you supplied (`supabase/public_lookup_migration.sql`,
unchanged copy). Its deployment state is **unknown to me**; do not assume it is installed.

## Check whether it is deployed (read-only)
In **Supabase ▸ SQL Editor** run:
```sql
select to_regprocedure('public.public_lookup_patient_by_code(text)') as fn,
       to_regclass('emr_internal.lookup_attempts')              as attempts_table;
```
Both columns non-null ⇒ it is installed. (If your function has a different argument type, the first column is null even though
a function exists: compare with the `create function` line in the migration.)
Test it as the anonymous role from any shell (replace `ANON` with the public anon key already in `index.html`):
```bash
curl -s https://pkzzktnxiboottirasvc.supabase.co/rest/v1/rpc/public_lookup_patient_by_code \
  -H "apikey: ANON" -H "Authorization: Bearer ANON" -H "Content-Type: application/json" \
  -d '{"p_code":"0000000000"}'
```
Expected for an unknown code: a JSON object with `"status"` (e.g. `not_found`), **not** an error saying the function does not exist and **not** patient data.
(Check the real parameter name in the migration's function definition and use it.)

## Deploy it (only after you read it and have a backup)
1. Run `supabase/2fd826a6-verify_anon_privileges.sql` (read-only) and read its notes.
2. Run `supabase/9ed0cb56-public_lookup_migration.sql` once. It is additive, re-runnable, aborts before changing anything if `public.patients` lacks a column it needs, and includes a rollback block.
3. Re-run the verify script. Confirm check 1 lists only the lookup function (plus intentionally public ones) for `anon`.
4. Then follow `docs/PUBLIC_LOOKUP_INSTALL_AND_TEST.md` (your file) for the rate-limit and IP-header checks.

## What the apps additionally need from the server
| Need | Where | Required? |
|---|---|---|
| Redirect URL `medicalcard://auth-callback` in Auth settings | Dashboard | Only for in-app reset links |
| CORS allowing `https://appassets.androidplatform.net` and `app://medicalcard` on Edge Functions | `ALLOWED_ORIGIN` secret | Only if you restricted it from the default `*` |
| Anything else (tables, RLS, RPCs, Auth providers) | — | **No change** |

PostgREST/Auth/Realtime accept the apps' origins without configuration. No migration is part of the apps.

## What I could not check (needs your project)
The SQL for admin functions and card-assignment RPCs was not supplied to me, so I could not audit their grants. `verify_anon_privileges.sql` check 1 does exactly that on your side.
