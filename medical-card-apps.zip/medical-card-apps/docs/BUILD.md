# Build, install and update

Nothing here has been run end-to-end by me (no SDK / registry access in my environment). Follow it on your machine or in GitHub Actions.

## 0. Prerequisites
| For | Need |
|---|---|
| Everything | Node.js 22, `npm install` once in the project root (downloads `esbuild` and `@supabase/supabase-js@2.45.4`) |
| Android | JDK 17, Android SDK platform 35 (Android Studio "Ladybug" or newer), Gradle 8.10.2 (Android Studio provides it; for the command line run `gradle wrapper --gradle-version 8.10.2` once inside `android/`) |
| Windows installer | A **Windows** machine (or the `windows-latest` GitHub runner), Node.js 22. Building the NSIS installer on Linux/macOS needs Wine and is not supported here. |

## 1. Shared web bundle (always first)
```bash
npm install
npm run build:www        # -> dist/android/www, dist/windows/www, MANIFEST.sha256
```
It fails loudly if `web/index.html` changed so that a patch no longer matches exactly once, if the key is not an anon/publishable key, or if any service-role/secret key appears.

## 2. Android → `MedicalCard.apk`
**Android Studio:** open the `android/` folder → let Gradle sync → *Build ▸ Build APK(s)* (debug) or *Generate Signed Bundle / APK ▸ APK* (release).

**Command line, debug (test only):**
```bash
gradle -p android :app:testDebugUnitTest :app:assembleDebug
cp android/app/build/outputs/apk/debug/app-debug.apk MedicalCard.apk
```
**Release (distributable) — you create and keep the signing key; I never generate or store one for you:**
```bash
keytool -genkeypair -v -keystore medicalcard-release.jks -alias medicalcard -keyalg RSA -keysize 2048 -validity 10000
export ANDROID_KEYSTORE_PATH=$PWD/medicalcard-release.jks ANDROID_KEYSTORE_PASSWORD=… ANDROID_KEY_ALIAS=medicalcard ANDROID_KEY_PASSWORD=…
gradle -p android :app:assembleRelease
cp android/app/build/outputs/apk/release/app-release.apk MedicalCard.apk
```
Back the `.jks` up somewhere safe and **never commit it** (`.gitignore` excludes it). If you lose it you cannot ship updates that install over the old app.
The **debug** APK uses a different application id (`….debug`) and turns off the screenshot block; do not distribute it.

**Install:** copy `MedicalCard.apk` to the phone → open it → allow "Install unknown apps" for your file manager/browser → Install. Or `adb install MedicalCard.apk`. Requires Android 8.0+ and an up-to-date *Android System WebView* (Chrome 86+).

## 3. Windows → `MedicalCardSetup.exe`
```bash
npm install && npm run build:www     # project root
cd windows
npm install
npm test                             # logic unit tests
npm run dist                         # -> ../dist/windows-installer/MedicalCardSetup.exe
```
Per-user install (no admin rights), Start-menu and desktop shortcuts, uninstaller, registers the `medicalcard://` link handler.
The installer is **not code-signed** unless you add your own certificate (electron-builder `CSC_LINK`/`CSC_KEY_PASSWORD` environment variables); Windows SmartScreen will show "unknown publisher" — click *More info ▸ Run anyway*, or sign it.
Run from source for debugging: `cd windows && npm start`.

## 4. GitHub Actions (reproducible pipeline)
`.github/workflows/build.yml` (run it from the *Actions* tab, or push a `v*` tag) builds the bundle, runs the tests, then builds the APK (ubuntu) and the installer (`windows-latest`) and uploads them as workflow artifacts. For a **signed** APK add four repository secrets: `ANDROID_KEYSTORE_BASE64` (`base64 -w0 medicalcard-release.jks`), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`. Without them the workflow builds a **debug** APK and says so.

## 5. Supabase dashboard settings the apps need
1. **Authentication ▸ URL Configuration ▸ Redirect URLs:** add `medicalcard://auth-callback` (keep your website URL). Needed only for in-app password-reset links (see 6).
2. If you restricted Edge Function CORS with `ALLOWED_ORIGIN`, add `https://appassets.androidplatform.net` and `app://medicalcard` (see 6). If `ALLOWED_ORIGIN` is unset (default `*`) nothing is needed.
3. Check/deploy the public-lookup migration: `docs/DATABASE_CHECK.md`.

## 6. Optional server patch (`server/functions/…`)
Based on the Edge Functions I delivered in the earlier migration. **Compare with what is actually deployed before overwriting.**
* `_shared/common.ts` — `ALLOWED_ORIGIN` may be a comma-separated list; the response echoes the caller's origin only if listed.
* `request-password-reset/index.ts` — uses `redirectTo` only when it is `SITE_URL` or `medicalcard://auth-callback`, otherwise `SITE_URL`.
Deploy: `supabase functions deploy request-password-reset login-with-id register-hospital`, and `supabase secrets set ALLOWED_ORIGIN=https://code-glitch8.github.io,https://appassets.androidplatform.net,app://medicalcard`.
**Without this patch** the apps still work; a reset email simply opens the website in the browser (where the reset can be finished) instead of returning to the app.

## 7. Updating
* **Website changed:** run `npm run build:www` again. If an exact-once patch no longer matches, the build stops and tells you which; adjust `scripts/build-www.mjs`, never hand-edit `dist/`.
* **New app version:** raise `versionCode`/`versionName` in `android/app/build.gradle.kts` and `version` in `windows/package.json`, rebuild. Android installs over the old app **only if signed with the same key**. The Windows installer upgrades in place.
* **Electron / supabase-js:** bump the versions in `windows/package.json` / root `package.json`, rebuild, retest. Do this regularly (see SECURITY.md).
