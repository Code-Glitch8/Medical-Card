# Security notes, findings, and what the apps do about them

## Controls implemented
| Area | Android | Windows |
|---|---|---|
| Page origin | virtual `https://appassets.androidplatform.net/www/…` from APK assets (no `file://`) | custom secure scheme `app://medicalcard`, traversal-safe handler |
| Native bridge | `addWebMessageListener` for that origin, main frame only; whitelisted commands; validated args (key regex, MAC regex, size caps); **no `addJavascriptInterface`** | preload exposes only `EMR_STORAGE`; `ipcMain` checks sender frame URL + key whitelist |
| Isolation | WebView: file/content access off, no geolocation, no multiple windows, mixed content blocked, Safe Browsing on | `contextIsolation`, `sandbox`, `nodeIntegration:false`, `webviewTag:false`, DevTools only in dev |
| Navigation | only app origin loads in-app; https links → system browser (user gesture only); everything else blocked | `will-navigate`/`will-redirect`/`window.open` locked; https → default browser |
| Network | CSP `connect-src` = Supabase https/wss; sub-requests to other hosts get 403; cleartext off | CSP + session-level allow-list (`onBeforeRequest`): only app + Supabase |
| Session token | AES-256-GCM key in Android Keystore, ciphertext in private prefs | Electron `safeStorage` (DPAPI); if unavailable, memory only — never plain text |
| Patient data | RAM of the page only; `LOAD_NO_CACHE`, `no-store`, cache cleared on destroy; `FLAG_SECURE` (no screenshots / recents thumbnail); no saved state; backup disabled | `no-store` on all responses, cache cleared on exit, `setContentProtection` (excluded from screen capture) |
| Public lookup | profile cleared when app goes to background / PC locks (`clearPublicProfile()`), plus the page's own 5-minute idle hide | same |
| Auto sign-out | on return after ≥ the page's auto-lock minutes the page's own `lockApp()` runs | same on unlock/resume |
| Logging | page console suppressed; bridge never logs payloads; no analytics | no logging of payloads; no analytics |
| Permissions | `INTERNET`, `BLUETOOTH_CONNECT` (API 31+), legacy `BLUETOOTH` (≤30). **No** location, scan, storage, camera, microphone | all denied except `serial` for the app origin |
| Secrets | build refuses `sb_secret_`/`service_role` keys; only the public anon key is in the page | same |

## Findings that need your decision (nothing was changed silently)
1. **Anon-executable write RPCs (possible, unverified).** Supabase grants `EXECUTE` on new functions to `anon` by default. If your write/admin RPCs were never revoked, an unauthenticated caller could invoke them (they may still check `auth.uid()` internally, which is why this needs your check, not a guess). *Check:* `verify_anon_privileges.sql` check 1. *Smallest safe fix per function:* `revoke execute on function public.<name>(<args>) from public, anon; grant execute … to authenticated;` — test the website afterwards. I did not apply this.
2. **A 10-digit code is a bearer secret** for a whole medical profile (your own file documents this). The app keeps the warning text from the website. Mitigations beyond rate limiting would need a product decision (second factor such as DOB; reduce public fields).
3. **Legacy 16-digit codes** are rejected by the public lookup by design; the apps do not change that.
4. **CORS default `*`** on the Edge Functions is acceptable for public sign-in endpoints but you may restrict it; if you do, add the app origins (BUILD.md §6).
5. **`style-src 'unsafe-inline'`** remains in the CSP because the page uses inline `style=""` attributes. Scripts are locked to the hashed inline script + bundled files, so this does not permit script injection.
6. **Electron is a browser you ship.** `windows/package.json` pins `~44.10.0`; supported majors as I last saw them (endoflife.date, 28 Oct 2026) were 43, 44, 45 with 43 ending 5 Jan 2027. Rebuild and re-release on every Electron security update. Android depends on the system WebView, which Google Play updates — the app asks the user to update it if it is too old.
7. **No certificate pinning.** The apps trust system CAs like a browser does.
8. **Unsigned Windows installer** triggers SmartScreen; sign with your own certificate for distribution.
9. **Rooted/jailbroken devices and malware** with accessibility rights can read screens; `FLAG_SECURE` is a deterrent, not a guarantee.
10. **Bluetooth link is not encrypted by this app.** HC-05 SPP pairing uses the module's legacy PIN security; card codes crossing that link could be sniffed by a nearby attacker with the right equipment. This is a property of the existing hardware design.

## Not verifiable here
CSP behaviour under the real `app://` scheme in Electron, `executeJavaScript` under CSP, Android `WebMessageListener` behaviour on real WebViews, and Keystore/DPAPI behaviour were not run. They are standard APIs, but treat them as untested until you run `docs/TESTING.md`.
