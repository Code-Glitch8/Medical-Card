# Emergency Medical Records — Medical Card: Android app and Windows installer

This project turns the existing website (<https://code-glitch8.github.io/Medical-Card/>, repo `Code-Glitch8/Medical-Card`) into

* **`MedicalCard.apk`** — Android app (Kotlin, one hardened WebView, native Bluetooth Classic bridge for the HC-05 reader)
* **`MedicalCardSetup.exe`** — Windows installer (Electron, built-in Web Serial → COM port picker)

Both apps show **the website's own `index.html`** (patched in three small, listed places, see `docs/CHANGES.md`) and talk to
**the same Supabase project** as the website: `https://pkzzktnxiboottirasvc.supabase.co`, the same public anon key, the same
RPCs, RLS and Auth. There is no new backend, no local patient database and no service-role key in any client.
The website keeps working on its own; nothing in `web/index.html` was changed.

## ⚠ Honest status — what was and was NOT done in the build environment
| Item | Status |
|---|---|
| Shared web bundle (`npm run build:www`) | **Built and tested** here (with a stand-in for supabase-js, because the npm registry was blocked) |
| `MedicalCard.apk` | **NOT built** — no Android SDK / Kotlin compiler / Gradle download was possible. Kotlin is written but **has never been compiled**. |
| `MedicalCardSetup.exe` | **NOT built** — no Electron / electron-builder / Windows. JS passes `node --check` and its pure-logic tests, but the app has **never been launched**. |
| Bluetooth / COM-port hardware | **Not tested** — no HC-05, no Arduino, no phone, no PC |
| Real Supabase | **Not contacted** — no network access to your project |

So: expect to fix small compile/launch errors on first build. `docs/BUILD.md` is the exact procedure, and
`.github/workflows/build.yml` builds both artifacts on GitHub's servers. `docs/TESTING.md` lists exactly what was run and what you must run.

## Layout
```
web/index.html            the website file, UNMODIFIED (source of truth)
scripts/build-www.mjs     builds the app bundle from it (3 asserted patches + CSP + secret scan)
shared/                   app-common.js (unsaved-edit guard, Back), platform-{android,windows,web}.js
android/                  Gradle/Kotlin project (MainActivity, NativeBridge, BluetoothSerial, SecureStore, Policy)
windows/                  Electron project (main.js, preload.js, serial picker, lib.js, electron-builder NSIS config)
server/                   OPTIONAL Edge Function patches (CORS for app origins, reset-link redirect)
supabase/                 your public_lookup_migration.sql + verify_anon_privileges.sql, unchanged
test/                     simulated bundle tests (Playwright + fake supabase)
docs/                     ARCHITECTURE, BUILD, DATABASE_CHECK, SECURITY, TESTING, HARDWARE, CHANGES
.github/workflows/        reproducible CI build
```

## Quick start
```bash
npm install && npm run build:www           # shared bundle -> dist/
gradle -p android assembleDebug            # APK (or open android/ in Android Studio)
cd windows && npm install && npm run dist  # on Windows: installer -> dist/windows-installer/MedicalCardSetup.exe
```
Full steps, signing and install instructions: **`docs/BUILD.md`**.

## Same Supabase project — confirmation
`build-www.mjs` reads `SUPABASE_URL` / `SUPABASE_KEY` from `web/index.html` (the website's own file) and refuses to build if
the key is not the public anon/publishable key. The Android Gradle build and the Electron main process read the host from that
same bundled file. The only Supabase identifiers anywhere in the apps are therefore the website's own.
