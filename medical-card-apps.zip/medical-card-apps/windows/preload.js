'use strict';
/* Runs in an isolated, sandboxed context. Exposes ONLY the encrypted session store to the page. */
const { contextBridge, ipcRenderer } = require('electron');
const call = (op, key, value) => ipcRenderer.invoke('emr:store', op, key, value);
contextBridge.exposeInMainWorld('EMR_STORAGE', {
  getItem: (k) => call('get', String(k)),
  setItem: (k, v) => call('set', String(k), String(v)).then(() => undefined),
  removeItem: (k) => call('remove', String(k)).then(() => undefined),
});
