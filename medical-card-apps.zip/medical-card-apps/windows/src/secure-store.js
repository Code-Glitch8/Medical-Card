'use strict';
const fs = require('node:fs');
const path = require('node:path');

/**
 * Login-session storage encrypted with Electron safeStorage (Windows DPAPI: bound to the signed-in Windows user).
 * If encryption is not available the session is kept in memory only; it is NEVER written in plain text.
 * Only whitelisted keys are accepted by the caller. No patient data is stored here.
 */
class SecureStore {
  constructor(dir, safeStorage) {
    this.file = path.join(dir, 'session.bin.json');
    this.ss = safeStorage;
    this.mem = new Map();
    this.disk = {};
    try { this.disk = JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { this.disk = {}; }
  }
  get canPersist() { return !!this.ss && this.ss.isEncryptionAvailable(); }
  get(key) {
    if (this.mem.has(key)) return this.mem.get(key);
    const raw = this.disk[key];
    if (!raw || !this.canPersist) return null;
    try { return this.ss.decryptString(Buffer.from(raw, 'base64')); } catch { delete this.disk[key]; this._flush(); return null; }
  }
  set(key, value) {
    if (this.canPersist) {
      this.disk[key] = this.ss.encryptString(value).toString('base64');
      this.mem.delete(key);
      this._flush();
    } else {
      this.mem.set(key, value);
    }
  }
  remove(key) { this.mem.delete(key); if (key in this.disk) { delete this.disk[key]; this._flush(); } }
  clear() { this.mem.clear(); this.disk = {}; this._flush(); }
  _flush() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.disk), { mode: 0o600 });
      fs.renameSync(tmp, this.file);
    } catch { /* storage failure must not crash the app; the user just signs in again */ }
  }
}
module.exports = { SecureStore };
