'use strict';
/* Pure helpers (no Electron imports) so they can be unit-tested with `node --test`. */
const path = require('node:path');

const APP_SCHEME = 'app';
const APP_HOST = 'medicalcard';
const APP_ORIGIN = `${APP_SCHEME}://${APP_HOST}`;
const START_URL = `${APP_ORIGIN}/index.html`;

const MAX_STORE_VALUE = 64 * 1024;
const STORE_KEY = /^sb-[a-z0-9]{10,30}-auth-token(-code-verifier|-user)?$/;
const FRAGMENT = /^[A-Za-z0-9_.~%=&+/-]{1,4096}$/;

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};
const mimeFor = (file) => MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';

/** Maps app://medicalcard/<path> to a file inside wwwRoot. Returns null for anything that could escape the folder. */
function resolveAppPath(wwwRoot, urlString) {
  let u;
  try { u = new URL(urlString); } catch { return null; }
  if (u.protocol !== `${APP_SCHEME}:` || u.hostname !== APP_HOST || u.username || u.password) return null;
  let p;
  try { p = decodeURIComponent(u.pathname); } catch { return null; }
  if (p === '/' || p === '') p = '/index.html';
  if (p.includes('\0') || p.includes('\\') || p.split('/').includes('..')) return null;
  const root = path.resolve(wwwRoot);
  const full = path.resolve(root, '.' + p);
  if (full !== root && !full.startsWith(root + path.sep)) return null;
  return full;
}

/** 'internal' | 'supabase' | 'external' | 'blocked' */
function classifyUrl(urlString, supabaseHost) {
  let u;
  try { u = new URL(urlString); } catch { return 'blocked'; }
  if (u.username || u.password) return 'blocked';
  if (u.protocol === `${APP_SCHEME}:`) return u.hostname === APP_HOST ? 'internal' : 'blocked';
  if (u.protocol === 'https:' || u.protocol === 'wss:') {
    if (u.port && u.port !== '443') return 'blocked';
    if (u.hostname.toLowerCase() === String(supabaseHost).toLowerCase()) return 'supabase';
    return u.protocol === 'https:' ? 'external' : 'blocked';
  }
  return 'blocked';
}

/** Subresource policy for the web request filter: only the app, the Supabase host, data:/blob:. */
function isRequestAllowed(urlString, supabaseHost) {
  if (/^(data|blob):/i.test(urlString)) return true;
  const z = classifyUrl(urlString, supabaseHost);
  return z === 'internal' || z === 'supabase';
}

/** medicalcard://auth-callback#<fragment> -> fragment | null */
function authFragment(link) {
  if (typeof link !== 'string') return null;
  let u;
  try { u = new URL(link); } catch { return null; }
  if (u.protocol !== 'medicalcard:' || u.hostname !== 'auth-callback') return null;
  const f = u.hash.startsWith('#') ? u.hash.slice(1) : '';
  return FRAGMENT.test(f) ? f : null;
}
const authUrl = (fragment, nonce) => `${START_URL}${nonce ? `?r=${nonce}` : ''}#${fragment}`;
const deepLinkFromArgv = (argv) => (argv || []).find((a) => typeof a === 'string' && a.startsWith('medicalcard://')) || null;

const isValidStoreKey = (k) => typeof k === 'string' && STORE_KEY.test(k);

function supabaseHostFromHtml(html) {
  const m = /const SUPABASE_URL='https:\/\/([a-z0-9.]+\.supabase\.co)'/.exec(html);
  return m ? m[1] : null;
}

/** Short, display-safe description of a serial port offered by Chromium's chooser. */
function describePort(p) {
  const clean = (s) => String(s ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 80);
  const port = clean(p.portName || p.name);
  const label = clean(p.displayName);
  return { id: String(p.portId), title: port || label || 'Serial port', detail: port && label && label !== port ? label : '' };
}

module.exports = {
  APP_SCHEME, APP_HOST, APP_ORIGIN, START_URL, MAX_STORE_VALUE, resolveAppPath, mimeFor, classifyUrl, isRequestAllowed,
  authFragment, authUrl, deepLinkFromArgv, isValidStoreKey, supabaseHostFromHtml, describePort,
};
