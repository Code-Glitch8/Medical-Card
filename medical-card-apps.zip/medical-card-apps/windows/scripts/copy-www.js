'use strict';
// Copies the shared, patched web bundle (built by `npm run build:www` in the project root) into windows/www.
const fs = require('node:fs');
const path = require('node:path');
const src = path.resolve(__dirname, '..', '..', 'dist', 'windows', 'www');
const dst = path.resolve(__dirname, '..', 'www');
if (!fs.existsSync(path.join(src, 'index.html'))) {
  console.error('dist/windows/www is missing. From the project root run:  npm install && npm run build:www');
  process.exit(1);
}
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
console.log('copied', src, '->', dst);
