'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const lib = require('../src/lib');
const { SecureStore } = require('../src/secure-store');
const SB = 'pkzzktnxiboottirasvc.supabase.co';
const ROOT = path.resolve('/tmp/www-root');

test('resolveAppPath serves files inside the root only', () => {
  assert.equal(lib.resolveAppPath(ROOT, 'app://medicalcard/index.html'), path.join(ROOT, 'index.html'));
  assert.equal(lib.resolveAppPath(ROOT, 'app://medicalcard/'), path.join(ROOT, 'index.html'));
  assert.equal(lib.resolveAppPath(ROOT, 'app://medicalcard/vendor/supabase.js'), path.join(ROOT, 'vendor', 'supabase.js'));
  // The URL parser already collapses "/../" to "/", so this stays inside the root (it can never leave it).
  assert.ok(lib.resolveAppPath(ROOT, 'app://medicalcard/../secret').startsWith(ROOT + path.sep));
  assert.ok(lib.resolveAppPath(ROOT, 'app://medicalcard/%2e%2e/secret').startsWith(ROOT + path.sep));
  for (const bad of ['app://medicalcard/a/..%2f..%2fx', 'app://medicalcard/a%5c..%5cb',
    'app://medicalcard/%00', 'app://other/index.html', 'https://medicalcard/index.html', 'app://u:p@medicalcard/index.html', 'not a url']) {
    assert.equal(lib.resolveAppPath(ROOT, bad), null, bad);
  }
});
test('classifyUrl', () => {
  assert.equal(lib.classifyUrl('app://medicalcard/index.html', SB), 'internal');
  assert.equal(lib.classifyUrl('app://evil/index.html', SB), 'blocked');
  assert.equal(lib.classifyUrl(`https://${SB}/rest/v1/rpc/x`, SB), 'supabase');
  assert.equal(lib.classifyUrl(`wss://${SB}/realtime/v1/websocket`, SB), 'supabase');
  assert.equal(lib.classifyUrl(`https://${SB}.evil.com/`, SB), 'external');
  assert.equal(lib.classifyUrl(`https://${SB}:8443/`, SB), 'blocked');
  assert.equal(lib.classifyUrl(`http://${SB}/`, SB), 'blocked');
  assert.equal(lib.classifyUrl('file:///C:/Windows/win.ini', SB), 'blocked');
  assert.equal(lib.classifyUrl('javascript:alert(1)', SB), 'blocked');
  assert.equal(lib.classifyUrl(`https://app:x@${SB}/`, SB), 'blocked');
  assert.equal(lib.classifyUrl('wss://evil.com/', SB), 'blocked');
});
test('isRequestAllowed', () => {
  assert.equal(lib.isRequestAllowed('app://medicalcard/index.html', SB), true);
  assert.equal(lib.isRequestAllowed(`https://${SB}/auth/v1/token`, SB), true);
  assert.equal(lib.isRequestAllowed('data:image/png;base64,AA', SB), true);
  assert.equal(lib.isRequestAllowed('https://cdn.jsdelivr.net/npm/x', SB), false);
  assert.equal(lib.isRequestAllowed('https://example.com/', SB), false);
});
test('deep links', () => {
  assert.equal(lib.authFragment('medicalcard://auth-callback#access_token=a.b.c&type=recovery'), 'access_token=a.b.c&type=recovery');
  assert.equal(lib.authFragment('medicalcard://other#x=1'), null);
  assert.equal(lib.authFragment('medicalcard://auth-callback'), null);
  assert.equal(lib.authFragment("medicalcard://auth-callback#a=b'c"), null);   // (< > " are percent-encoded by the URL parser and stay inert)
  assert.equal(lib.authFragment('https://auth-callback#a=b'), null);
  assert.equal(lib.authFragment(undefined), null);
  assert.equal(lib.deepLinkFromArgv(['C:\\x.exe', '--flag', 'medicalcard://auth-callback#a=b']), 'medicalcard://auth-callback#a=b');
  assert.equal(lib.deepLinkFromArgv(['x.exe']), null);
  assert.equal(lib.authUrl('a=b'), 'app://medicalcard/index.html#a=b');
  assert.equal(lib.authUrl('a=b', 5), 'app://medicalcard/index.html?r=5#a=b');
});
test('store keys', () => {
  assert.ok(lib.isValidStoreKey('sb-pkzzktnxiboottirasvc-auth-token'));
  assert.ok(lib.isValidStoreKey('sb-pkzzktnxiboottirasvc-auth-token-code-verifier'));
  assert.ok(!lib.isValidStoreKey('../x'));
  assert.ok(!lib.isValidStoreKey(null));
});
test('supabase host is read from the page', () => {
  assert.equal(lib.supabaseHostFromHtml("const SUPABASE_URL='https://pkzzktnxiboottirasvc.supabase.co';"), SB);
  assert.equal(lib.supabaseHostFromHtml("const SUPABASE_URL='https://evil.com';"), null);
});
test('describePort strips control characters and bounds length', () => {
  const d = lib.describePort({ portId: 7, portName: 'COM5', displayName: 'Standard Serial over Bluetooth link (COM5)\u0007' + 'x'.repeat(200) });
  assert.equal(d.id, '7'); assert.equal(d.title, 'COM5'); assert.ok(d.detail.length <= 80); assert.ok(!/[\u0000-\u001f]/.test(d.detail));
});
test('SecureStore: encrypted when available, memory-only (never plain text) when not', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'emr-'));
  const fake = { isEncryptionAvailable: () => true, encryptString: (s) => Buffer.from(s.split('').reverse().join('')), decryptString: (b) => b.toString().split('').reverse().join('') };
  const s = new SecureStore(dir, fake);
  s.set('k', 'secret-token'); assert.equal(s.get('k'), 'secret-token');
  assert.ok(!fs.readFileSync(path.join(dir, 'session.bin.json'), 'utf8').includes('secret-token'));
  assert.equal(new SecureStore(dir, fake).get('k'), 'secret-token');
  s.remove('k'); assert.equal(s.get('k'), null);
  const dir2 = fs.mkdtempSync(path.join(os.tmpdir(), 'emr-'));
  const none = new SecureStore(dir2, { isEncryptionAvailable: () => false });
  none.set('k', 'plain-secret'); assert.equal(none.get('k'), 'plain-secret');
  assert.ok(!fs.existsSync(path.join(dir2, 'session.bin.json')));
});
