'use strict';
const { app, BrowserWindow, protocol, session, ipcMain, safeStorage, shell, Menu, powerMonitor, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const lib = require('./src/lib');
const { SecureStore } = require('./src/secure-store');

// ---- one instance only (a second launch, e.g. from a password-reset link, is forwarded to the first) ---------------
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }

protocol.registerSchemesAsPrivileged([
  // secure + standard => crypto.subtle (needed by the PKCE login flow), fetch and ES modules work like on https
  { scheme: lib.APP_SCHEME, privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

const WWW = path.join(__dirname, 'www');
let supabaseHost = null;
let win = null;
let picker = null;
let pickerCallback = null;
let store = null;
let pendingDeepLink = lib.deepLinkFromArgv(process.argv);
let leftAt = 0;

const isAppSender = (e) => !!win && e.sender === win.webContents && String(e.senderFrame && e.senderFrame.url).startsWith(lib.APP_ORIGIN + '/');

// ---- encrypted session store ---------------------------------------------------------------------------------------
ipcMain.handle('emr:store', (e, op, key, value) => {
  if (!isAppSender(e) || !lib.isValidStoreKey(key)) throw new Error('not allowed');
  if (op === 'get') return store.get(key);
  if (op === 'set') {
    if (typeof value !== 'string' || value.length > lib.MAX_STORE_VALUE) throw new Error('value too large');
    store.set(key, value); return null;
  }
  if (op === 'remove') { store.remove(key); return null; }
  throw new Error('unknown op');
});

// ---- serial port chooser (Web Serial is built into Chromium; this only lets the user pick the COM port) ---------------
function sendPickerList(list) { if (picker && !picker.isDestroyed()) picker.webContents.send('picker:list', list.map(lib.describePort)); }
function closePicker(portId) {
  const cb = pickerCallback; pickerCallback = null;
  if (picker && !picker.isDestroyed()) { const p = picker; picker = null; p.destroy(); }
  picker = null;
  if (cb) cb(portId || '');                       // '' = cancelled -> navigator.serial.requestPort rejects (NotFoundError)
}
let lastPorts = [];
function wireSerial(ses) {
  ses.on('select-serial-port', (event, portList, webContents, callback) => {
    event.preventDefault();
    if (!win || webContents !== win.webContents) { callback(''); return; }
    lastPorts = portList.slice();
    if (pickerCallback) { pickerCallback(''); }   // a newer request replaces an older one
    pickerCallback = callback;
    if (!picker || picker.isDestroyed()) {
      picker = new BrowserWindow({
        parent: win, modal: true, width: 460, height: 420, minimizable: false, maximizable: false, resizable: true,
        title: 'Choose the card reader', autoHideMenuBar: true, show: false,
        webPreferences: { preload: path.join(__dirname, 'picker-preload.js'), contextIsolation: true, sandbox: true, nodeIntegration: false, devTools: !app.isPackaged },
      });
      picker.removeMenu();
      picker.on('closed', () => { picker = null; if (pickerCallback) closePicker(''); });
      picker.webContents.once('did-finish-load', () => { sendPickerList(lastPorts); picker.show(); });
      picker.loadFile(path.join(__dirname, 'picker.html'));
    } else sendPickerList(lastPorts);
  });
  ses.on('serial-port-added', (_e, port) => { lastPorts = lastPorts.concat(port); sendPickerList(lastPorts); });
  ses.on('serial-port-removed', (_e, port) => { lastPorts = lastPorts.filter((p) => p.portId !== port.portId); sendPickerList(lastPorts); });
}
ipcMain.on('picker:choose', (e, id) => {
  if (!picker || e.sender !== picker.webContents) return;
  closePicker(id === null ? '' : String(id));
});

// ---- hardening --------------------------------------------------------------------------------------------------------
function hardenSession(ses) {
  // Only serial (for the card reader) and only for the app's own origin. Every other permission is denied.
  ses.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
  ses.setPermissionCheckHandler((_wc, permission, origin, details) =>
    permission === 'serial' && String((details && details.securityOrigin) || origin).startsWith(lib.APP_ORIGIN));
  ses.setDevicePermissionHandler((d) => d.deviceType === 'serial' && String(d.origin).startsWith(lib.APP_ORIGIN));
  // Network allow-list: the app itself and the one Supabase project (https + wss). Nothing else leaves the machine.
  ses.webRequest.onBeforeRequest((details, cb) => cb({ cancel: !app.isPackaged && details.url.startsWith('devtools:') ? false : !lib.isRequestAllowed(details.url, supabaseHost) }));
  ses.webRequest.onHeadersReceived((details, cb) => {
    const h = { ...details.responseHeaders };
    for (const k of Object.keys(h)) if (/^cache-control$/i.test(k)) delete h[k];
    h['Cache-Control'] = ['no-store'];
    cb({ responseHeaders: h });
  });
}

app.on('web-contents-created', (_e, wc) => {
  const guard = (e, url) => {
    const zone = lib.classifyUrl(url, supabaseHost);
    if (zone === 'internal' && wc === (win && win.webContents)) return;
    e.preventDefault();
    if (zone === 'external') shell.openExternal(url);         // https only, in the user's default browser
  };
  wc.on('will-navigate', guard);
  wc.on('will-redirect', guard);
  wc.setWindowOpenHandler(({ url }) => { if (lib.classifyUrl(url, supabaseHost) === 'external') shell.openExternal(url); return { action: 'deny' }; });
  wc.on('will-attach-webview', (e) => e.preventDefault());
});

// ---- window ---------------------------------------------------------------------------------------------------------------
function createWindow() {
  win = new BrowserWindow({
    width: 1200, height: 860, minWidth: 360, minHeight: 560, show: false, backgroundColor: '#0b6477',
    title: 'Emergency Medical Records — Medical Card', autoHideMenuBar: true,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, sandbox: true, nodeIntegration: false, nodeIntegrationInSubFrames: false,
      webSecurity: true, allowRunningInsecureContent: false, webviewTag: false, spellcheck: false,
      devTools: !app.isPackaged, partition: 'persist:emr',   // localStorage only holds theme + auto-lock minutes
    },
  });
  win.once('ready-to-show', () => win.show());
  win.on('closed', () => { win = null; });
  win.setContentProtection(app.isPackaged);                    // excludes the window from screen capture (patient data)
  const target = pendingDeepLink && lib.authFragment(pendingDeepLink) ? lib.authUrl(lib.authFragment(pendingDeepLink)) : lib.START_URL;
  pendingDeepLink = null;
  win.loadURL(target);
}

function openDeepLink(link) {
  const frag = lib.authFragment(link);
  if (!frag || !win) return;
  if (win.isMinimized()) win.restore();
  win.focus();
  win.loadURL(lib.authUrl(frag, Date.now()));                  // a new query string forces a real reload so the page reads the fragment
}

app.on('second-instance', (_e, argv) => {
  const link = lib.deepLinkFromArgv(argv);
  if (link) openDeepLink(link); else if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
});

// ---- lock when the PC locks / sleeps ------------------------------------------------------------------------------------------
function js(code) { if (win && !win.isDestroyed()) win.webContents.executeJavaScript(code, false).catch(() => {}); }
function onLeave() { leftAt = Date.now(); js('try{clearPublicProfile()}catch(e){}'); }
function onReturn() {
  if (!leftAt) return;
  const away = Date.now() - leftAt; leftAt = 0;
  js(`try{if(typeof me!=='undefined'&&me&&!demo&&${Number(away)}>=autoLockMinutes()*60000)lockApp('Signed out after the computer was locked or asleep.')}catch(e){}`);
}

app.whenReady().then(() => {
  const html = fs.readFileSync(path.join(WWW, 'index.html'), 'utf8');
  supabaseHost = lib.supabaseHostFromHtml(html);
  if (!supabaseHost) { dialog.showErrorBox('Medical Card', 'The app package is damaged (no Supabase project configured). Reinstall it.'); app.quit(); return; }

  store = new SecureStore(app.getPath('userData'), safeStorage);

  protocol.handle(lib.APP_SCHEME, async (req) => {
    const file = lib.resolveAppPath(WWW, req.url);
    if (!file) return new Response('Not found', { status: 404 });
    try {
      const data = await fs.promises.readFile(file);
      return new Response(data, { headers: { 'Content-Type': lib.mimeFor(file), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
    } catch { return new Response('Not found', { status: 404 }); }
  });

  const ses = session.fromPartition('persist:emr');
  hardenSession(ses);
  wireSerial(ses);
  if (app.isPackaged) { Menu.setApplicationMenu(null); app.setAsDefaultProtocolClient('medicalcard'); }

  powerMonitor.on('lock-screen', onLeave);
  powerMonitor.on('suspend', onLeave);
  powerMonitor.on('unlock-screen', onReturn);
  powerMonitor.on('resume', onReturn);

  createWindow();
});

app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => {
  const ses = session.fromPartition('persist:emr');
  ses.clearCache().catch(() => {});
  ses.clearStorageData({ storages: ['cachestorage', 'serviceworkers'] }).catch(() => {});
});
