'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('picker', {
  onList: (cb) => ipcRenderer.on('picker:list', (_e, list) => cb(list)),
  choose: (id) => ipcRenderer.send('picker:choose', id === null ? null : String(id)),
});
