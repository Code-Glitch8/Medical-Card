#!/usr/bin/env node
/**
 * Builds the web bundle used inside the Android and Windows apps from the UNMODIFIED website file web/index.html.
 *
 *   node scripts/build-www.mjs [--target android|windows|web|all] [--vendor-file path/to/supabase-esm.js] [--out dist]
 *
 * What it does (every replacement is asserted to match exactly once, so a changed index.html fails loudly instead of
 * silently producing a different app):
 *   1. loads supabase-js from the bundle (./vendor/supabase.js, built with esbuild from the pinned npm package) instead of a CDN
 *   2. lets the shell supply a secure session store (window.EMR_STORAGE); the website keeps using sessionStorage
 *   3. lets the password-reset request carry an allow-listed redirect (window.EMR_REDIRECT_TO); ignored by older servers
 *   4. adds a Content-Security-Policy whose script hash covers exactly the page's one inline script
 *   5. adds app-common.js (unsaved-edit guard, Back handling) and platform.js (per-platform shim)
 *   6. refuses to build if anything that looks like a service-role / secret key is present
 * The website at https://code-glitch8.github.io/Medical-Card/ is not touched and keeps working on its own.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const argv = process.argv.slice(2);
const opt = (name, def) => { const i = argv.indexOf('--' + name); return i >= 0 ? argv[i + 1] : def; };
const targets = (opt('target', 'all') === 'all' ? ['android', 'windows'] : [opt('target')]);
const outRoot = path.resolve(root, opt('out', 'dist'));
const vendorFile = opt('vendor-file', null);

const die = (m) => { console.error('build-www: ' + m); process.exit(1); };

let html = fs.readFileSync(path.join(root, 'web/index.html'), 'utf8');

function replaceOnce(label, from, to) {
  const n = html.split(from).length - 1;
  if (n !== 1) die(`patch "${label}" expected exactly 1 match in web/index.html, found ${n}. The website changed; review scripts/build-www.mjs.`);
  html = html.replace(from, () => to);
}

// ---- 1-3: code patches ---------------------------------------------------------------------------------------------
replaceOnce('vendored supabase-js',
  "const m=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@'+SUPABASE_JS+'/+esm');",
  "const m=await import('./vendor/supabase.js');");
replaceOnce('session store hook',
  'storage:window.sessionStorage,',
  'storage:(window.EMR_STORAGE||window.sessionStorage),');
replaceOnce('password-reset redirect',
  "await call('requestPasswordReset',{identifier:$('forgotId').value.trim()})",
  "await call('requestPasswordReset',{identifier:$('forgotId').value.trim(),redirectTo:window.EMR_REDIRECT_TO||undefined})");

// ---- 6: secret scan + public configuration ------------------------------------------------------------------------
const url = (html.match(/const SUPABASE_URL='([^']+)'/) || [])[1];
const key = (html.match(/const SUPABASE_KEY='([^']+)'/) || [])[1];
if (!url || !key) die('SUPABASE_URL / SUPABASE_KEY not found in index.html');
if (!/^https:\/\/[a-z0-9]{10,30}\.supabase\.co$/.test(url)) die('SUPABASE_URL is not an https://<ref>.supabase.co URL');
if (key.startsWith('sb_secret_')) die('SUPABASE_KEY is a SECRET key. Never ship it in a client.');
if (!key.startsWith('sb_publishable_')) {
  let role = null;
  try { role = JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString('utf8')).role; } catch { /* handled below */ }
  if (role !== 'anon') die(`SUPABASE_KEY must be the public anon/publishable key (JWT role "anon"), found role "${role}".`);
}
if (/service_role|sb_secret_/.test(html.replace(/\/\/.*$/gm, '').replace(/'service_role'/g, ''))) {
  // the only legitimate mentions would be words in comments; be strict and stop for a human to look
  if (/eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}/.test(html)) {
    for (const m of html.match(/eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}/g)) {
      let role = null; try { role = JSON.parse(Buffer.from(m.split('.')[1], 'base64url').toString('utf8')).role; } catch { /* ignore */ }
      if (role === 'service_role') die('A service_role JWT is present in the page. Remove it.');
    }
  }
}
const host = new URL(url).host;

// ---- 4: CSP with a hash of the page's single inline script -------------------------------------------------------------
const scriptRe = /<script>('use strict';[\s\S]*?)<\/script>/g;
const inline = [...html.matchAll(scriptRe)].filter((m) => m[1].includes('const SUPABASE_URL'));
if (inline.length !== 1) die(`expected exactly one inline application script, found ${inline.length}`);
const scriptText = inline[0][1];
const hash = crypto.createHash('sha256').update(scriptText, 'utf8').digest('base64');
const csp = [
  "default-src 'none'",
  `script-src 'self' 'sha256-${hash}'`,
  "style-src 'self' 'unsafe-inline'",   // the page uses style="" attributes
  "img-src 'self' data:",
  "font-src 'self' data:",
  `connect-src https://${host} wss://${host}`,
  "base-uri 'none'",
  "form-action 'none'",
  "object-src 'none'",
].join('; ');

// ---- 5: shared scripts + CSP meta ------------------------------------------------------------------------------------
replaceOnce('CSP meta', '<meta charset="utf-8">', `<meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${csp}">`);
const scriptOpen = '<script>' + scriptText.slice(0, 20);
const idx = html.indexOf(scriptOpen);
if (idx < 0) die('could not locate the application script after patching');
html = html.slice(0, idx) + '<script src="app-common.js"></script><script src="platform.js"></script>' + html.slice(idx);

// ---- vendor bundle ---------------------------------------------------------------------------------------------------
async function makeVendor(dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  if (vendorFile) { fs.copyFileSync(path.resolve(vendorFile), dest); return 'file:' + vendorFile; }
  let esbuild;
  try { esbuild = await import('esbuild'); } catch { die('esbuild is not installed. Run "npm install" in the project root (needs the npm registry), or pass --vendor-file.'); }
  await esbuild.build({
    stdin: { contents: "export { createClient } from '@supabase/supabase-js';", resolveDir: root, loader: 'js' },
    bundle: true, format: 'esm', platform: 'browser', target: 'es2020', minify: true, legalComments: 'none', outfile: dest,
  });
  return 'npm @supabase/supabase-js';
}

// ---- write targets ----------------------------------------------------------------------------------------------------
const common = fs.readFileSync(path.join(root, 'shared/app-common.js'));
for (const t of targets) {
  const dir = path.join(outRoot, t, 'www');
  fs.rmSync(path.join(outRoot, t), { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.html'), html);
  fs.writeFileSync(path.join(dir, 'app-common.js'), common);
  const platformSrc = { android: 'shared/platform-android.js', windows: 'shared/platform-windows.js', web: 'shared/platform-web.js' }[t];
  if (!platformSrc) die('unknown target ' + t);
  fs.copyFileSync(path.join(root, platformSrc), path.join(dir, 'platform.js'));
  const vendorSrc = await makeVendor(path.join(dir, 'vendor/supabase.js'));
  // secret scan of everything that will be shipped
  for (const f of ['index.html', 'app-common.js', 'platform.js', 'vendor/supabase.js']) {
    const s = fs.readFileSync(path.join(dir, f), 'utf8');
    if (/sb_secret_/.test(s)) die(`${f} contains an sb_secret_ key`);
    for (const m of s.match(/eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}/g) || []) {
      let role = null; try { role = JSON.parse(Buffer.from(m.split('.')[1], 'base64url').toString('utf8')).role; } catch { /* not a JWT */ }
      if (role && role !== 'anon') die(`${f} contains a JWT with role "${role}"`);
    }
  }
  const lines = fs.readdirSync(dir, { recursive: true, withFileTypes: true }).filter((e) => e.isFile()).map((e) => {
    const p = path.join(e.parentPath ?? e.path, e.name);
    return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex') + '  ' + path.relative(dir, p);
  });
  fs.writeFileSync(path.join(outRoot, t, 'MANIFEST.sha256'), lines.sort().join('\n') + '\n');
  console.log(`built ${t}: ${path.relative(root, dir)}  (supabase-js from ${vendorSrc}; CSP script hash sha256-${hash.slice(0, 12)}…)`);
}
