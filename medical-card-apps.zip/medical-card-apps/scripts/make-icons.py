#!/usr/bin/env python3
"""Draws the Windows app icon (white medical cross on the brand blue). Needs Pillow: pip install pillow."""
from PIL import Image, ImageDraw
import pathlib
out = pathlib.Path(__file__).resolve().parent.parent / 'windows' / 'build'
out.mkdir(parents=True, exist_ok=True)
S = 1024
im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.rounded_rectangle((0, 0, S - 1, S - 1), radius=S // 5, fill=(11, 100, 119, 255))
w, l = S * 0.20, S * 0.58
c = S / 2
d.rounded_rectangle((c - w / 2, c - l / 2, c + w / 2, c + l / 2), radius=S * 0.04, fill='white')
d.rounded_rectangle((c - l / 2, c - w / 2, c + l / 2, c + w / 2), radius=S * 0.04, fill='white')
im.resize((512, 512), Image.LANCZOS).save(out / 'icon.png')
im.save(out / 'icon.ico', sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print('wrote', out / 'icon.png', out / 'icon.ico')
