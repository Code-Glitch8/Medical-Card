package io.github.codeglitch8.medicalcard

import io.github.codeglitch8.medicalcard.Policy.Zone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PolicyTest {
    private val sb = "pkzzktnxiboottirasvc.supabase.co"

    @Test fun appPagesAreInternal() {
        assertEquals(Zone.INTERNAL, Policy.classify(Policy.START_URL, sb))
        assertEquals(Zone.INTERNAL, Policy.classify("https://appassets.androidplatform.net/www/vendor/supabase.js", sb))
    }
    @Test fun appOriginOutsideWwwIsBlocked() {
        assertEquals(Zone.BLOCKED, Policy.classify("https://appassets.androidplatform.net/other", sb))
    }
    @Test fun supabaseHostOnly() {
        assertEquals(Zone.SUPABASE, Policy.classify("https://$sb/rest/v1/rpc/x", sb))
        assertEquals(Zone.EXTERNAL_HTTPS, Policy.classify("https://$sb.evil.com/", sb))
        assertEquals(Zone.EXTERNAL_HTTPS, Policy.classify("https://evil-$sb/", sb))
    }
    @Test fun trickyUrlsAreBlockedOrExternal() {
        assertEquals(Zone.BLOCKED, Policy.classify("https://appassets.androidplatform.net@evil.com/www/index.html", sb))
        assertEquals(Zone.BLOCKED, Policy.classify("http://$sb/", sb))
        assertEquals(Zone.BLOCKED, Policy.classify("file:///etc/passwd", sb))
        assertEquals(Zone.BLOCKED, Policy.classify("javascript:alert(1)", sb))
        assertEquals(Zone.BLOCKED, Policy.classify("intent://x#Intent;end", sb))
        assertEquals(Zone.BLOCKED, Policy.classify("https://$sb:8443/", sb))
        assertEquals(Zone.BLOCKED, Policy.classify(null, sb))
        assertEquals(Zone.BLOCKED, Policy.classify("", sb))
    }
    @Test fun storeKeyWhitelist() {
        assertTrue(Policy.isValidStoreKey("sb-pkzzktnxiboottirasvc-auth-token"))
        assertTrue(Policy.isValidStoreKey("sb-pkzzktnxiboottirasvc-auth-token-code-verifier"))
        assertFalse(Policy.isValidStoreKey("sb-pkzzktnxiboottirasvc-auth-token/../x"))
        assertFalse(Policy.isValidStoreKey("anything"))
        assertFalse(Policy.isValidStoreKey(null))
    }
    @Test fun macValidation() {
        assertTrue(Policy.isValidMac("00:11:22:AA:BB:CC"))
        assertFalse(Policy.isValidMac("00:11:22:aa:bb:cc"))
        assertFalse(Policy.isValidMac("00:11:22:AA:BB"))
        assertFalse(Policy.isValidMac("../../etc"))
    }
    @Test fun authFragment() {
        assertEquals("access_token=a.b.c&type=recovery", Policy.authFragment("medicalcard://auth-callback#access_token=a.b.c&type=recovery"))
        assertNull(Policy.authFragment("medicalcard://other#access_token=a"))
        assertNull(Policy.authFragment("https://auth-callback#access_token=a"))
        assertNull(Policy.authFragment("medicalcard://auth-callback"))
        assertNull(Policy.authFragment("medicalcard://auth-callback#<script>"))
        assertNull(Policy.authFragment(null))
        assertEquals("https://appassets.androidplatform.net/www/index.html#a=b", Policy.authUrl("a=b"))
    }
}
