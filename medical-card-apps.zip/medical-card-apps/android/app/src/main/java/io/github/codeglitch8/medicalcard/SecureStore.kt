package io.github.codeglitch8.medicalcard

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores the Supabase login session (access/refresh token) encrypted with an AES-256-GCM key that lives in the
 * Android Keystore (hardware-backed where the device has it) and never leaves it. Only whitelisted keys are accepted
 * (see Policy.STORE_KEY). No patient data is ever stored here.
 */
class SecureStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("emr_secure", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    @Synchronized
    fun get(name: String): String? {
        val raw = prefs.getString(name, null) ?: return null
        return try {
            val all = Base64.decode(raw, Base64.NO_WRAP)
            val iv = all.copyOfRange(0, IV_LEN)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(all, IV_LEN, all.size - IV_LEN), Charsets.UTF_8)
        } catch (e: Exception) {
            // Key invalidated or data corrupt: treat as signed out rather than crash.
            prefs.edit().remove(name).apply()
            null
        }
    }

    @Synchronized
    fun set(name: String, value: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(name, Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)).apply()
    }

    @Synchronized
    fun remove(name: String) { prefs.edit().remove(name).apply() }

    @Synchronized
    fun clear() { prefs.edit().clear().apply() }

    private companion object {
        const val ALIAS = "emr_session_key_v1"
        const val IV_LEN = 12
    }
}
