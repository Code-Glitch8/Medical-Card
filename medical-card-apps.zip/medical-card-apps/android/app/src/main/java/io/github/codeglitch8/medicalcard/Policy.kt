package io.github.codeglitch8.medicalcard

import java.net.URI

/**
 * Pure (Android-free) security policy, so it can be unit-tested on the JVM.
 * Everything the WebView and the native bridge accept from web content is checked here.
 */
object Policy {
    /** Virtual HTTPS origin served from the APK's assets by WebViewAssetLoader (never reachable over the network). */
    const val APP_HOST = "appassets.androidplatform.net"
    const val APP_ORIGIN = "https://$APP_HOST"
    /** assets/www/index.html is packaged by Gradle from dist/android/www. */
    const val START_URL = "$APP_ORIGIN/www/index.html"

    const val MAX_STORE_VALUE = 64 * 1024
    const val MAX_WRITE_BYTES = 4096
    const val MAX_MESSAGE_CHARS = 128 * 1024

    /** supabase-js session keys only: sb-<project-ref>-auth-token[-code-verifier|-user]. */
    val STORE_KEY = Regex("^sb-[a-z0-9]{10,30}-auth-token(-code-verifier|-user)?$")
    val MAC = Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$")
    /** URL-fragment characters allowed in an auth callback (base64url, '.', '=', '&', '%'). */
    val FRAGMENT = Regex("^[A-Za-z0-9_.~%=&+/-]{1,4096}$")

    enum class Zone { INTERNAL, SUPABASE, EXTERNAL_HTTPS, BLOCKED }

    fun classify(url: String?, supabaseHost: String): Zone {
        if (url.isNullOrEmpty()) return Zone.BLOCKED
        val u = try { URI(url) } catch (e: Exception) { return Zone.BLOCKED }
        if (u.scheme?.lowercase() != "https") return Zone.BLOCKED
        if (u.rawUserInfo != null) return Zone.BLOCKED
        val host = u.host?.lowercase() ?: return Zone.BLOCKED
        if (u.port != -1 && u.port != 443) return Zone.BLOCKED
        return when {
            host == APP_HOST -> if ((u.rawPath ?: "").startsWith("/www/")) Zone.INTERNAL else Zone.BLOCKED
            host == supabaseHost.lowercase() -> Zone.SUPABASE
            else -> Zone.EXTERNAL_HTTPS
        }
    }

    fun isValidStoreKey(k: String?) = k != null && STORE_KEY.matches(k)
    fun isValidMac(a: String?) = a != null && MAC.matches(a)

    /** medicalcard://auth-callback#<fragment>  ->  fragment, or null when the link is not acceptable. */
    fun authFragment(link: String?): String? {
        if (link == null) return null
        val u = try { URI(link) } catch (e: Exception) { return null }
        if (u.scheme?.lowercase() != "medicalcard" || u.host?.lowercase() != "auth-callback") return null
        val f = u.rawFragment ?: return null
        return if (FRAGMENT.matches(f)) f else null
    }

    fun authUrl(fragment: String, nonce: Long? = null) = START_URL + (nonce?.let { "?r=$it" } ?: "") + "#" + fragment
}
