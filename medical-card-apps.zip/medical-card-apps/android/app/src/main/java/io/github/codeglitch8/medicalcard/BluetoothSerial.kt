package io.github.codeglitch8.medicalcard

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Bluetooth Classic SPP (RFCOMM) client for the paired HC-05 reader. The bytes are passed through unchanged, so the
 * Arduino line protocol (ARM:/WRITE:/CARD:/CODE:/INFO:/ERR:) is identical to the website's Web Serial workflow.
 *
 * Only devices that are already bonded (paired in Android Settings) can be used; the app never scans, so it needs no
 * location permission. State is only reported as connected after connect() really succeeded.
 *
 * NOT hardware-tested in the build environment (no Android device / HC-05 available there).
 */
class BluetoothSerial(
    context: Context,
    private val onData: (ByteArray) -> Unit,
    private val onClosed: (String) -> Unit,
) {
    data class Dev(val name: String, val address: String)

    private val adapter: BluetoothAdapter? =
        (context.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var generation = 0
    private val lock = Any()

    val isSupported get() = adapter != null
    val isEnabled get() = adapter?.isEnabled == true

    /** Caller must hold BLUETOOTH_CONNECT (API 31+). */
    @SuppressLint("MissingPermission")
    fun bonded(): List<Dev> {
        val a = adapter ?: return emptyList()
        return try {
            a.bondedDevices.orEmpty().map { Dev(it.name ?: it.address, it.address.uppercase()) }.sortedBy { it.name.lowercase() }
        } catch (e: SecurityException) { emptyList() }
    }

    /** Blocking. Throws IOException / SecurityException / IllegalArgumentException with a user-presentable message. */
    @SuppressLint("MissingPermission")
    fun open(address: String) {
        val a = adapter ?: throw IOException("This device has no Bluetooth.")
        if (!a.isEnabled) throw IOException("Bluetooth is turned off. Turn it on and try again.")
        val dev = bonded().firstOrNull { it.address == address }
            ?: throw IllegalArgumentException("That reader is not paired. Pair it in Android Bluetooth settings first.")
        closeInternal("replaced")
        val remote = a.getRemoteDevice(dev.address)
        val s = remote.createRfcommSocketToServiceRecord(SPP)
        try {
            a.cancelDiscovery()
            s.connect()                       // throws if the reader is off / out of range / wrong PIN
        } catch (e: IOException) {
            try { s.close() } catch (_: IOException) {}
            throw IOException("Could not connect to the reader. Check it is powered, in range and paired.")
        }
        val gen: Int
        synchronized(lock) {
            gen = ++generation
            socket = s
            out = s.outputStream
        }
        val input = s.inputStream
        Thread({ readLoop(gen, input) }, "emr-bt-read").apply { isDaemon = true }.start()
    }

    private fun readLoop(gen: Int, input: InputStream) {
        val buf = ByteArray(512)
        var reason = "closed"
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) { reason = "remote-closed"; break }
                if (n > 0) onData(buf.copyOf(n))
                if (gen != generation) return
            }
        } catch (e: IOException) {
            reason = if (gen == generation) "link-lost" else "closed"
        }
        val current: Boolean
        synchronized(lock) {
            current = gen == generation
            if (current) { try { socket?.close() } catch (_: IOException) {}; socket = null; out = null }
        }
        if (current) onClosed(reason)
    }

    @Throws(IOException::class)
    fun write(bytes: ByteArray) {
        val o = out ?: throw IOException("The reader is not connected.")
        try { synchronized(o) { o.write(bytes); o.flush() } } catch (e: IOException) { throw IOException("Writing to the reader failed.") }
    }

    fun close() = closeInternal("closed")

    private fun closeInternal(@Suppress("UNUSED_PARAMETER") why: String) {
        synchronized(lock) {
            generation++                       // invalidates any running read loop so it will not report a late "closed"
            try { socket?.close() } catch (_: IOException) {}
            socket = null; out = null
        }
    }

    companion object {
        /** Standard Serial Port Profile UUID used by HC-05 modules. */
        val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}
