package io.github.codeglitch8.medicalcard

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.Executors

/**
 * The only channel between the web page and native code. Registered with WebViewCompat.addWebMessageListener for the
 * app's own origin only (no addJavascriptInterface, so no object is exposed to other frames or origins).
 *
 * Accepts a small whitelist of commands, validates every argument, and never logs payloads.
 *   store.get/set/remove   encrypted session storage (whitelisted keys)
 *   serial.pick            user chooses one of the already-paired Bluetooth devices
 *   serial.open/write/close  RFCOMM SPP link to the chosen device
 */
class NativeBridge(
    private val host: Host,
    private val store: SecureStore,
    private val serial: BluetoothSerial,
) : WebViewCompat.WebMessageListener {

    interface Host {
        /** Show the device picker (asking for BLUETOOTH_CONNECT if needed). Must call back exactly once, on the main thread. */
        fun pickDevice(callback: (BluetoothSerial.Dev?, String?) -> Unit)
    }

    private val main = Handler(Looper.getMainLooper())
    private val storeExec = Executors.newSingleThreadExecutor()
    private val serialExec = Executors.newSingleThreadExecutor()   // single thread keeps writes in order
    @Volatile private var reply: JavaScriptReplyProxy? = null
    /** Addresses the user explicitly picked in this page load (mirrors Web Serial's per-origin grant). */
    private val granted = HashSet<String>()

    /** Called by MainActivity whenever a page starts loading: forget the page's grants and drop any open link. */
    fun reset() {
        reply = null
        synchronized(granted) { granted.clear() }
        serial.close()
    }

    fun shutdown() { reset(); storeExec.shutdownNow(); serialExec.shutdownNow() }

    override fun onPostMessage(
        view: android.webkit.WebView, message: WebMessageCompat, sourceOrigin: Uri, isMainFrame: Boolean, replyProxy: JavaScriptReplyProxy,
    ) {
        if (!isMainFrame || sourceOrigin.toString() != Policy.APP_ORIGIN) return
        val text = message.data ?: return
        if (text.length > Policy.MAX_MESSAGE_CHARS) return
        reply = replyProxy
        val m = try { JSONObject(text) } catch (e: Exception) { return }
        val id = m.optInt("id", -1)
        if (id < 0) return
        try {
            when (m.optString("cmd")) {
                "store.get" -> {
                    val k = key(m)
                    storeExec.execute { respond(id) { put("value", store.get(k) ?: JSONObject.NULL) } }
                }
                "store.set" -> {
                    val k = key(m)
                    val v = m.optString("value", "")
                    if (v.length > Policy.MAX_STORE_VALUE) throw Bad("Value too large.")
                    storeExec.execute { respond(id) { store.set(k, v) } }
                }
                "store.remove" -> {
                    val k = key(m)
                    storeExec.execute { respond(id) { store.remove(k) } }
                }
                "serial.pick" -> {
                    if (!serial.isSupported) throw Bad("This device has no Bluetooth.", "NotSupportedError")
                    main.post {
                        host.pickDevice { dev, err ->
                            if (dev == null) fail(id, "NotFoundError", err ?: "No reader was selected.")
                            else {
                                synchronized(granted) { granted.add(dev.address) }
                                respond(id) { put("address", dev.address); put("name", dev.name) }
                            }
                        }
                    }
                }
                "serial.open" -> {
                    val a = m.optString("address").uppercase()
                    if (!Policy.isValidMac(a)) throw Bad("Invalid device address.")
                    if (!synchronized(granted) { granted.contains(a) }) throw Bad("Choose the reader first.", "SecurityError")
                    serialExec.execute {
                        try { serial.open(a); respond(id) {} }
                        catch (e: IllegalArgumentException) { fail(id, "NotFoundError", e.message ?: "Reader not found.") }
                        catch (e: SecurityException) { fail(id, "SecurityError", "Bluetooth permission was not granted.") }
                        catch (e: IOException) { fail(id, "NetworkError", e.message ?: "Could not connect.") }
                    }
                }
                "serial.write" -> {
                    val bytes = try { Base64.decode(m.optString("b64"), Base64.NO_WRAP) } catch (e: IllegalArgumentException) { throw Bad("Bad data.") }
                    if (bytes.isEmpty() || bytes.size > Policy.MAX_WRITE_BYTES) throw Bad("Bad data length.")
                    serialExec.execute {
                        try { serial.write(bytes); respond(id) {} } catch (e: IOException) { fail(id, "NetworkError", e.message ?: "Write failed.") }
                    }
                }
                "serial.close" -> serialExec.execute { serial.close(); respond(id) {} }
                else -> throw Bad("Unknown command.")
            }
        } catch (e: Bad) {
            fail(id, e.kind, e.message ?: "Request rejected.")
        }
    }

    // ---- events pushed to the page ---------------------------------------------------------------------------------
    fun pushData(bytes: ByteArray) = push(JSONObject().put("event", "serial.data").put("b64", Base64.encodeToString(bytes, Base64.NO_WRAP)))
    fun pushClosed(reason: String) = push(JSONObject().put("event", "serial.closed").put("reason", reason))

    private fun push(o: JSONObject) {
        val s = o.toString()
        main.post { try { reply?.postMessage(s) } catch (_: Exception) { /* page went away */ } }
    }

    private class Bad(message: String, val kind: String = "TypeError") : Exception(message)

    private fun key(m: JSONObject): String {
        val k = m.optString("key")
        if (!Policy.isValidStoreKey(k)) throw Bad("Key not allowed.", "SecurityError")
        return k
    }

    private inline fun respond(id: Int, fill: JSONObject.() -> Unit) {
        val o = JSONObject().put("id", id).put("ok", true)
        try { o.fill() } catch (e: Exception) { fail(id, "UnknownError", "Request failed."); return }
        val s = o.toString()
        main.post { try { reply?.postMessage(s) } catch (_: Exception) {} }
    }

    private fun fail(id: Int, name: String, message: String) {
        val s = JSONObject().put("id", id).put("ok", false).put("name", name).put("message", message).toString()
        main.post { try { reply?.postMessage(s) } catch (_: Exception) {} }
    }
}
