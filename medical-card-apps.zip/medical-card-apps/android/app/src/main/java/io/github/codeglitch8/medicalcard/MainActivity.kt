package io.github.codeglitch8.medicalcard

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

/**
 * One full-screen WebView that shows the website's own page, packaged inside the APK (assets/www), served from the
 * virtual origin https://appassets.androidplatform.net. All data comes from the same Supabase project as the website.
 *
 * Not compiled or run in the build environment (no Android SDK there): compile with the steps in docs/BUILD.md.
 */
class MainActivity : AppCompatActivity(), NativeBridge.Host {

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var serial: BluetoothSerial
    private lateinit var bridge: NativeBridge
    private lateinit var assetLoader: WebViewAssetLoader
    private var pickCallback: ((BluetoothSerial.Dev?, String?) -> Unit)? = null
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (BuildConfig.SECURE_WINDOW) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(Policy.APP_HOST)
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        serial = BluetoothSerial(this, { bridge.pushData(it) }, { bridge.pushClosed(it) })
        bridge = NativeBridge(this, SecureStore(this), serial)

        root = FrameLayout(this)
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        createWebView()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goBack()
        })

        // Cold start: either the normal start page or, when opened from a password-reset email, the page plus the link's fragment.
        load(Policy.authFragment(intent?.dataString)?.let { Policy.authUrl(it) } ?: Policy.START_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView() {
        web = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(ContextCompat.getColor(this@MainActivity, R.color.brand))
            overScrollMode = WebView.OVER_SCROLL_NEVER
            isLongClickable = false
            settings.apply {
                javaScriptEnabled = true            // the app is a JavaScript page
                domStorageEnabled = true            // theme / auto-lock preference (localStorage); no tokens are kept there
                allowFileAccess = false
                allowContentAccess = false
                @Suppress("DEPRECATION") allowFileAccessFromFileURLs = false
                @Suppress("DEPRECATION") allowUniversalAccessFromFileURLs = false
                setGeolocationEnabled(false)
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                mediaPlaybackRequiresUserGesture = true
                cacheMode = WebSettings.LOAD_NO_CACHE   // medical responses are never cached on disk
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                safeBrowsingEnabled = true
                @Suppress("DEPRECATION") saveFormData = false
            }
            webViewClient = AppClient()
            webChromeClient = AppChrome()
        }
        root.addView(web)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            AlertDialog.Builder(this)
                .setTitle("Update Android System WebView")
                .setMessage("This app needs a newer Android System WebView (Chrome 86 or later). Update it in Google Play, then reopen the app.")
                .setCancelable(false).setPositiveButton("Close") { _, _ -> finish() }.show()
            return
        }
        WebViewCompat.addWebMessageListener(web, "EMRNative", setOf(Policy.APP_ORIGIN), bridge)
    }

    private fun load(url: String) { if (Policy.classify(url, BuildConfig.SUPABASE_HOST) == Policy.Zone.INTERNAL) web.loadUrl(url) }

    // ---- WebViewClient: only the app origin and the Supabase host may load; everything else is blocked or sent to the browser
    private inner class AppClient : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val zone = Policy.classify(request.url.toString(), BuildConfig.SUPABASE_HOST)
            return when (zone) {
                Policy.Zone.INTERNAL -> assetLoader.shouldInterceptRequest(request.url)?.also { r ->
                    val h = HashMap(r.responseHeaders ?: emptyMap())
                    h["Cache-Control"] = "no-store"
                    h["X-Content-Type-Options"] = "nosniff"
                    r.responseHeaders = h
                }
                Policy.Zone.SUPABASE -> null                       // normal network request to the project's API
                else -> WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url.toString()
            when (Policy.classify(url, BuildConfig.SUPABASE_HOST)) {
                Policy.Zone.INTERNAL -> return false
                Policy.Zone.EXTERNAL_HTTPS -> if (request.hasGesture()) openInBrowser(url)
                else -> {}
            }
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) { bridge.reset() }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            // The page process died (memory pressure or crash): discard it and start clean; the user signs in again if needed.
            root.removeView(web); web.destroy()
            createWebView(); load(Policy.START_URL)
            return true
        }
        // onReceivedSslError is intentionally not overridden: the default is to cancel the load.
    }

    private fun openInBrowser(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)) } catch (_: Exception) {}
    }

    // ---- JS dialogs (the page uses confirm() for unsaved-edit and destructive actions) and hardening -----------------
    private inner class AppChrome : WebChromeClient() {
        override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(message).setCancelable(false)
                .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }.show(); return true
        }
        override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(message).setCancelable(false)
                .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }.show(); return true
        }
        override fun onJsPrompt(view: WebView, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
            val input = EditText(this@MainActivity).apply { setText(defaultValue ?: "") }
            AlertDialog.Builder(this@MainActivity).setMessage(message).setView(input).setCancelable(false)
                .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }.show(); return true
        }
        override fun onPermissionRequest(request: PermissionRequest) = request.deny()   // no camera / microphone
        override fun onConsoleMessage(m: ConsoleMessage?): Boolean = true                // never write page output to logcat
    }

    // ---- Back button: let the page step back first, then confirm before leaving the app -----------------------------------
    private fun goBack() {
        web.evaluateJavascript("(function(){try{return window.__emrBack?window.__emrBack():'exit'}catch(e){return 'exit'}})()") { r ->
            if (r?.trim('"') != "handled") {
                AlertDialog.Builder(this).setMessage("Exit Emergency Medical Records?")
                    .setPositiveButton("Exit") { _, _ -> finish() }.setNegativeButton("Stay", null).show()
            }
        }
    }

    // ---- Deep link: password-reset email -> medicalcard://auth-callback#access_token=...&type=recovery ----------------
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // A different query string forces a real page load, so the page re-reads the new fragment.
        Policy.authFragment(intent.dataString)?.let { load(Policy.authUrl(it, SystemClock.elapsedRealtime())) }
    }

    // ---- Lifecycle: clear on-screen medical data when leaving, and auto sign-out after the configured idle time ----------
    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
        // The public lookup shows a patient's emergency data: remove it from the page as soon as the app is left.
        web.evaluateJavascript("try{clearPublicProfile()}catch(e){}", null)
    }

    override fun onStart() {
        super.onStart()
        if (stoppedAt == 0L) return
        val away = SystemClock.elapsedRealtime() - stoppedAt
        stoppedAt = 0L
        web.evaluateJavascript(
            "try{if(typeof me!=='undefined'&&me&&!demo&&$away>=autoLockMinutes()*60000)lockApp('Signed out after the app was in the background.')}catch(e){}", null
        )
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // Deliberately not saving WebView state: it would put page contents (medical data) into the saved-state bundle.
    }

    override fun onDestroy() {
        bridge.shutdown()
        web.apply { stopLoading(); clearHistory(); clearCache(true); removeAllViews(); destroy() }
        super.onDestroy()
    }

    // ---- Bluetooth device picker (paired devices only) ----------------------------------------------------------------------
    override fun pickDevice(callback: (BluetoothSerial.Dev?, String?) -> Unit) {
        if (pickCallback != null) { callback(null, "A reader selection is already open."); return }
        pickCallback = callback
        if (needsBtPermission()) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQ_BT)
        } else showPicker()
    }

    private fun needsBtPermission() =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_BT) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) showPicker()
        else finishPick(null, "Bluetooth permission was denied. Allow it in the app's settings, or enter the 10-digit code manually.")
    }

    private fun showPicker() {
        if (!serial.isEnabled) { finishPick(null, "Bluetooth is turned off. Turn it on and try again."); return }
        val devs = serial.bonded()
        if (devs.isEmpty()) {
            finishPick(null, "No paired Bluetooth devices. Pair the HC-05 reader in Android Bluetooth settings first (PIN is usually 1234 or 0000).")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Choose the card reader")
            .setItems(devs.map { "${it.name}\n${it.address}" }.toTypedArray()) { _, i -> finishPick(devs[i], null) }
            .setNegativeButton(android.R.string.cancel) { _, _ -> finishPick(null, "No reader was selected.") }
            .setOnCancelListener { finishPick(null, "No reader was selected.") }
            .show()
    }

    private fun finishPick(d: BluetoothSerial.Dev?, err: String?) {
        val cb = pickCallback ?: return
        pickCallback = null
        cb(d, err)
    }

    private companion object { const val REQ_BT = 41 }
}
