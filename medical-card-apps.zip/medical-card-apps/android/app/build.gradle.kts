plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The Supabase host is read from the website file the bundle is built from, so there is a single source of truth.
// Only the PUBLIC project URL is used here; no key is read or embedded by Gradle.
val wwwIndex = rootProject.file("../dist/android/www/index.html")
val supabaseHost: String = if (wwwIndex.exists()) {
    Regex("const SUPABASE_URL='https://([a-z0-9.]+\\.supabase\\.co)'").find(wwwIndex.readText())?.groupValues?.get(1)
        ?: throw GradleException("SUPABASE_URL not found in ${wwwIndex.path}")
} else {
    "pending-build-www.supabase.co" // placeholder so Android Studio can sync before the bundle exists
}

android {
    namespace = "io.github.codeglitch8.medicalcard"
    compileSdk = 35

    defaultConfig {
        applicationId = "io.github.codeglitch8.medicalcard"
        minSdk = 26          // Android 8.0: needs an updatable WebView with web-message listeners (Chrome 86+)
        targetSdk = 35       // Android 15
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "SUPABASE_HOST", "\"$supabaseHost\"")
        buildConfigField("boolean", "SECURE_WINDOW", "true") // blocks screenshots / recent-apps thumbnails of medical data
    }

    val keystorePath: String? = System.getenv("ANDROID_KEYSTORE_PATH")
    signingConfigs {
        if (keystorePath != null) {
            create("release") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ANDROID_KEY_ALIAS")
                keyPassword = System.getenv("ANDROID_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keystorePath != null) signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            buildConfigField("boolean", "SECURE_WINDOW", "false")
        }
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    sourceSets["main"].assets.srcDir(rootProject.file("../dist/android"))
    packaging { resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}") }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    testImplementation("junit:junit:4.13.2")
}

val verifyWww = tasks.register("verifyWww") {
    doLast {
        if (!wwwIndex.exists()) throw GradleException("dist/android/www is missing. From the project root run:  npm install && npm run build:www")
    }
}
tasks.named("preBuild") { dependsOn(verifyWww) }
