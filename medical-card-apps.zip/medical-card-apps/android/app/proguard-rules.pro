# The app has no reflection-based code. androidx.webkit ships its own consumer rules.
-dontwarn org.jspecify.annotations.**
